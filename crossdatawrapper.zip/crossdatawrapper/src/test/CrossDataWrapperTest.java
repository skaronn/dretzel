package test;
import static org.junit.Assert.*;

import org.junit.Test;


public class CrossDataWrapperTest {

	@Test
	public void test() {
		assertTrue(Boolean.TRUE);
	}

}
