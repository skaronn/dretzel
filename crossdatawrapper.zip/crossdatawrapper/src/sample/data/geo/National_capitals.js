[
		{
			"City" : "Abu Dhabi",
			"Country" : "United Arab Emirates",
			"Notes" : ""
		},
		{
			"City" : "Abuja",
			"Country" : "Nigeria",
			"Notes" : ""
		},
		{
			"City" : "Accra",
			"Country" : "Ghana",
			"Notes" : ""
		},
		{
			"City" : "Adamstown",
			"Country" : "Pitcairn Islands",
			"Notes" : "British Overseas Territory"
		},
		{
			"City" : "Addis Ababa",
			"Country" : "Ethiopia",
			"Notes" : ""
		},
		{
			"City" : "Algiers",
			"Country" : "Algeria",
			"Notes" : ""
		},
		{
			"City" : "Alofi",
			"Country" : "Niue",
			"Notes" : "free association New Zealand"
		},
		{
			"City" : "Amman",
			"Country" : "Jordan",
			"Notes" : ""
		},
		{
			"City" : "Amsterdam",
			"Country" : "Netherlands",
			"Notes" : ""
		},
		{
			"City" : "Andorra la Vella",
			"Country" : "Andorra",
			"Notes" : ""
		},
		{
			"City" : "Ankara",
			"Country" : "Turkey",
			"Notes" : ""
		},
		{
			"City" : "Antananarivo",
			"Country" : "Madagascar",
			"Notes" : ""
		},
		{
			"City" : "Apia",
			"Country" : "Samoa",
			"Notes" : ""
		},
		{
			"City" : "Ashgabat",
			"Country" : "Turkmenistan",
			"Notes" : ""
		},
		{
			"City" : "Asmara",
			"Country" : "Eritrea",
			"Notes" : ""
		},
		{
			"City" : "Astana",
			"Country" : "Kazakhstan",
			"Notes" : ""
		},
		{
			"City" : "Asunci\u00f3n",
			"Country" : "Paraguay",
			"Notes" : ""
		},
		{
			"City" : "Athens",
			"Country" : "Greece",
			"Notes" : ""
		},
		{
			"City" : "Avarua",
			"Country" : "Cook Islands",
			"Notes" : "free association New Zealand"
		},
		{
			"City" : "Baghdad",
			"Country" : "Iraq",
			"Notes" : ""
		},
		{
			"City" : "Baku",
			"Country" : "Azerbaijan",
			"Notes" : ""
		},
		{
			"City" : "Bamako",
			"Country" : "Mali",
			"Notes" : ""
		},
		{
			"City" : "Bandar Seri Begawan",
			"Country" : "Brunei",
			"Notes" : ""
		},
		{
			"City" : "Bangkok",
			"Country" : "Thailand",
			"Notes" : ""
		},
		{
			"City" : "Bangui",
			"Country" : "Central African Republic",
			"Notes" : ""
		},
		{
			"City" : "Banjul",
			"Country" : "Gambia",
			"Notes" : ""
		},
		{
			"City" : "Basseterre",
			"Country" : "Saint Kitts and Nevis",
			"Notes" : ""
		},
		{
			"City" : "Beijing",
			"Country" : "China",
			"Notes" : ""
		},
		{
			"City" : "Beirut",
			"Country" : "Lebanon",
			"Notes" : ""
		},
		{
			"City" : "Belfast",
			"Country" : "Northern Ireland",
			"Notes" : "Country of the United Kingdom"
		},
		{
			"City" : "Belgrade",
			"Country" : "Serbia",
			"Notes" : ""
		},
		{
			"City" : "Belmopan",
			"Country" : "Belize",
			"Notes" : ""
		},
		{
			"City" : "Berlin",
			"Country" : "Germany",
			"Notes" : ""
		},
		{
			"City" : "Bern",
			"Country" : "Switzerland",
			"Notes" : ""
		},
		{
			"City" : "Bishkek",
			"Country" : "Kyrgyzstan",
			"Notes" : ""
		},
		{
			"City" : "Bissau",
			"Country" : "Guinea-Bissau",
			"Notes" : ""
		},
		{
			"City" : "Bogot\u00e1",
			"Country" : "Colombia",
			"Notes" : ""
		},
		{
			"City" : "Bras\u00edlia",
			"Country" : "Brazil",
			"Notes" : ""
		},
		{
			"City" : "Bratislava",
			"Country" : "Slovakia",
			"Notes" : ""
		},
		{
			"City" : "Brazzaville",
			"Country" : "Republic of the Congo",
			"Notes" : ""
		},
		{
			"City" : "Bridgetown",
			"Country" : "Barbados",
			"Notes" : ""
		},
		{
			"City" : "Brussels",
			"Country" : "Belgium",
			"Notes" : ""
		},
		{
			"City" : "Bucharest",
			"Country" : "Romania",
			"Notes" : ""
		},
		{
			"City" : "Budapest",
			"Country" : "Hungary",
			"Notes" : ""
		},
		{
			"City" : "Buenos Aires",
			"Country" : "Argentina",
			"Notes" : ""
		},
		{
			"City" : "Bujumbura",
			"Country" : "Burundi",
			"Notes" : ""
		},
		{
			"City" : "Cairo",
			"Country" : "Egypt",
			"Notes" : ""
		},
		{
			"City" : "Canberra",
			"Country" : "Australia",
			"Notes" : ""
		},
		{
			"City" : "Caracas",
			"Country" : "Venezuela",
			"Notes" : ""
		},
		{
			"City" : "Cardiff",
			"Country" : "Wales",
			"Notes" : "Country of the United Kingdom"
		},
		{
			"City" : "Castries",
			"Country" : "Saint Lucia",
			"Notes" : ""
		},
		{
			"City" : "Cayenne",
			"Country" : "French Guiana",
			"Notes" : ""
		},
		{
			"City" : "Charlotte Amalie",
			"Country" : "United States Virgin Islands",
			"Notes" : "Territory United States"
		},
		{
			"City" : "Chisinau",
			"Country" : "Moldova",
			"Notes" : ""
		},
		{
			"City" : "Cockburn Town",
			"Country" : "Turks and Caicos Islands",
			"Notes" : "British Overseas Territory"
		},
		{
			"City" : "Conakry",
			"Country" : "Guinea",
			"Notes" : ""
		},
		{
			"City" : "Copenhagen",
			"Country" : "Denmark",
			"Notes" : ""
		},
		{
			"City" : "Dakar",
			"Country" : "Senegal",
			"Notes" : ""
		},
		{
			"City" : "Damascus",
			"Country" : "Syria",
			"Notes" : ""
		},
		{
			"City" : "Dhaka",
			"Country" : "Bangladesh",
			"Notes" : ""
		},
		{
			"City" : "Dili",
			"Country" : "East Timor",
			"Notes" : ""
		},
		{
			"City" : "Djibouti",
			"Country" : "Djibouti",
			"Notes" : ""
		},
		{
			"City" : "Dodoma",
			"Country" : "Tanzania",
			"Notes" : ""
		},
		{
			"City" : "Doha",
			"Country" : "Qatar",
			"Notes" : ""
		},
		{
			"City" : "Douglas",
			"Country" : "Isle of Man",
			"Notes" : "Crown Dependency"
		},
		{
			"City" : "Dublin",
			"Country" : "Ireland",
			"Notes" : ""
		},
		{
			"City" : "Dushanbe",
			"Country" : "Tajikistan",
			"Notes" : ""
		},
		{
			"City" : "Edinburgh",
			"Country" : "Scotland",
			"Notes" : "Country of the United Kingdom"
		},
		{
			"City" : "Edinburgh of the Seven Seas",
			"Country" : "Tristan da Cunha",
			"Notes" : "British Overseas Territory"
		},
		{
			"City" : "El Aai\u00fan",
			"Country" : "Western Sahara",
			"Notes" : "82 other states Free Zone Morocco Tindouf Algeria"
		},
		{
			"City" : "Episkopi Cantonment",
			"Country" : "Akrotiri and Dhekelia",
			"Notes" : "British Overseas Territory"
		},
		{
			"City" : "Flying Fish Cove",
			"Country" : "Christmas Island",
			"Notes" : "External territory Australia"
		},
		{
			"City" : "Freetown",
			"Country" : "Sierra Leone",
			"Notes" : ""
		},
		{
			"City" : "Funafuti",
			"Country" : "Tuvalu",
			"Notes" : ""
		},
		{
			"City" : "Gaborone",
			"Country" : "Botswana",
			"Notes" : ""
		},
		{
			"City" : "George Town",
			"Country" : "Cayman Islands",
			"Notes" : "British Overseas Territory"
		},
		{
			"City" : "Georgetown",
			"Country" : "Ascension Island"
		},
		{
			"City" : "Georgetown",
			"Country" : "Guyana",
			"Notes" : ""
		},
		{
			"City" : "Gibraltar",
			"Country" : "Gibraltar",
			"Notes" : "British Overseas Territory"
		},
		{
			"City" : "Grytviken",
			"Country" : "South Georgia and the South Sandwich Islands",
			"Notes" : "British Overseas Territory"
		},
		{
			"City" : "Guatemala City",
			"Country" : "Guatemala",
			"Notes" : ""
		},
		{
			"City" : "Gustavia",
			"Country" : "Saint Barth\u00e9lemy",
			"Notes" : "Overseas collectivity France"
		},
		{
			"City" : "Hag\u00e5t\u00f1a",
			"Country" : "Guam",
			"Notes" : "Territory United States"
		},
		{
			"City" : "Hamilton",
			"Country" : "Bermuda",
			"Notes" : "British Overseas Territory"
		},
		{
			"City" : "Hanga Roa",
			"Country" : "Easter Island",
			"Notes" : "Chile"
		},
		{
			"City" : "Hanoi",
			"Country" : "Vietnam",
			"Notes" : ""
		},
		{
			"City" : "Harare",
			"Country" : "Zimbabwe",
			"Notes" : ""
		},
		{
			"City" : "Hargeisa",
			"Country" : "Somaliland",
			"Notes" : "Somali Republic"
		},
		{
			"City" : "Havana",
			"Country" : "Cuba",
			"Notes" : ""
		},
		{
			"City" : "Helsinki",
			"Country" : "Finland",
			"Notes" : ""
		},
		{
			"City" : "Honiara",
			"Country" : "Solomon Islands",
			"Notes" : ""
		},
		{
			"City" : "Islamabad",
			"Country" : "Pakistan",
			"Notes" : ""
		},
		{
			"City" : "Jakarta",
			"Country" : "Indonesia",
			"Notes" : ""
		},
		{
			"City" : "Jamestown",
			"Country" : "Saint Helena",
			"Notes" : "British Overseas Territory"
		},
		{
			"City" : "Jerusalem",
			"Country" : "Israel",
			"Notes" : "Jerusalem Law parliament United Nations Security Council Resolution 478 United Nations Tel Aviv Ramat Gan Herzliya CIA Factbook Map of Israel Palestinian Authority East Jerusalem future Palestinian state"
		},
		{
			"City" : "Jerusalem",
			"Country" : "Palestine",
			"Notes" : "State of Palestine"
		},
		{
			"City" : "Juba",
			"Country" : "South Sudan",
			"Notes" : ""
		},
		{
			"City" : "Kabul",
			"Country" : "Afghanistan",
			"Notes" : ""
		},
		{
			"City" : "Kampala",
			"Country" : "Uganda",
			"Notes" : ""
		},
		{
			"City" : "Kathmandu",
			"Country" : "Nepal",
			"Notes" : ""
		},
		{
			"City" : "Khartoum",
			"Country" : "Sudan",
			"Notes" : ""
		},
		{
			"City" : "Kiev",
			"Country" : "Ukraine",
			"Notes" : ""
		},
		{
			"City" : "Kigali",
			"Country" : "Rwanda",
			"Notes" : ""
		},
		{
			"City" : "Kingston",
			"Country" : "Jamaica",
			"Notes" : ""
		},
		{
			"City" : "Kingston",
			"Country" : "Norfolk Island",
			"Notes" : "External territory Australia"
		},
		{
			"City" : "Kingstown",
			"Country" : "Saint Vincent and the Grenadines",
			"Notes" : ""
		},
		{
			"City" : "Kinshasa",
			"Country" : "Democratic Republic of the Congo",
			"Notes" : ""
		},
		{
			"City" : "Kuala Lumpur",
			"Country" : "Malaysia",
			"Notes" : ""
		},
		{
			"City" : "Kuwait City",
			"Country" : "Kuwait",
			"Notes" : ""
		},
		{
			"City" : "La Paz",
			"Country" : "Bolivia",
			"Notes" : ""
		},
		{
			"City" : "Libreville",
			"Country" : "Gabon",
			"Notes" : ""
		},
		{
			"City" : "Lilongwe",
			"Country" : "Malawi",
			"Notes" : ""
		},
		{
			"City" : "Lima",
			"Country" : "Peru",
			"Notes" : ""
		},
		{
			"City" : "Lisbon",
			"Country" : "Portugal",
			"Notes" : ""
		},
		{
			"City" : "Ljubljana",
			"Country" : "Slovenia",
			"Notes" : ""
		},
		{
			"City" : "Lom\u00e9",
			"Country" : "Togo",
			"Notes" : ""
		},
		{
			"City" : "London",
			"Country" : "United Kingdom  England",
			"Notes" : "England Country of the United Kingdom United Kingdom"
		},
		{
			"City" : "Luanda",
			"Country" : "Angola",
			"Notes" : ""
		},
		{
			"City" : "Lusaka",
			"Country" : "Zambia",
			"Notes" : ""
		},
		{
			"City" : "Luxembourg",
			"Country" : "Luxembourg",
			"Notes" : ""
		},
		{
			"City" : "Madrid",
			"Country" : "Spain",
			"Notes" : ""
		},
		{
			"City" : "Majuro",
			"Country" : "Marshall Islands",
			"Notes" : ""
		},
		{
			"City" : "Malabo",
			"Country" : "Equatorial Guinea",
			"Notes" : ""
		},
		{
			"City" : "Mal\u00e9",
			"Country" : "Maldives",
			"Notes" : ""
		},
		{
			"City" : "Mamoudzou",
			"Country" : "Mayotte",
			"Notes" : "Overseas collectivity France"
		},
		{
			"City" : "Managua",
			"Country" : "Nicaragua",
			"Notes" : ""
		},
		{
			"City" : "Manama",
			"Country" : "Bahrain",
			"Notes" : ""
		},
		{
			"City" : "Manila",
			"Country" : "Philippines",
			"Notes" : ""
		},
		{
			"City" : "Maputo",
			"Country" : "Mozambique",
			"Notes" : ""
		},
		{
			"City" : "Marigot",
			"Country" : "Saint Martin",
			"Notes" : "Overseas collectivity France"
		},
		{
			"City" : "Maseru",
			"Country" : "Lesotho",
			"Notes" : ""
		},
		{
			"City" : "Mata-Utu",
			"Country" : "Wallis and Futuna",
			"Notes" : "Overseas collectivity France"
		},
		{
			"City" : "Mbabane",
			"Country" : "Swaziland",
			"Notes" : ""
		},
		{
			"City" : "Mexico City",
			"Country" : "Mexico",
			"Notes" : ""
		},
		{
			"City" : "Minsk",
			"Country" : "Belarus",
			"Notes" : ""
		},
		{
			"City" : "Mogadishu",
			"Country" : "Somalia",
			"Notes" : ""
		},
		{
			"City" : "Monaco",
			"Country" : "Monaco",
			"Notes" : ""
		},
		{
			"City" : "Monrovia",
			"Country" : "Liberia",
			"Notes" : ""
		},
		{
			"City" : "Montevideo",
			"Country" : "Uruguay",
			"Notes" : ""
		},
		{
			"City" : "Moroni",
			"Country" : "Comoros",
			"Notes" : ""
		},
		{
			"City" : "Moscow",
			"Country" : "Russia",
			"Notes" : ""
		},
		{
			"City" : "Muscat",
			"Country" : "Oman",
			"Notes" : ""
		},
		{
			"City" : "Nairobi",
			"Country" : "Kenya",
			"Notes" : ""
		},
		{
			"City" : "Nassau",
			"Country" : "Bahamas",
			"Notes" : ""
		},
		{
			"City" : "Naypyidaw",
			"Country" : "Myanmar",
			"Notes" : ""
		},
		{
			"City" : "N'Djamena",
			"Country" : "Chad",
			"Notes" : ""
		},
		{
			"City" : "New Delhi",
			"Country" : "India",
			"Notes" : ""
		},
		{
			"City" : "Ngerulmud",
			"Country" : "Palau",
			"Notes" : ""
		},
		{
			"City" : "Niamey",
			"Country" : "Niger",
			"Notes" : ""
		},
		{
			"City" : "Nicosia",
			"Country" : "Cyprus",
			"Notes" : ""
		},
		{
			"City" : "Nicosia",
			"Country" : "Northern Cyprus",
			"Notes" : "Turkey Republic of Cyprus"
		},
		{
			"City" : "Nouakchott",
			"Country" : "Mauritania",
			"Notes" : ""
		},
		{
			"City" : "Noum\u00e9a",
			"Country" : "New Caledonia",
			"Notes" : "Sui generis collectivity France"
		},
		{
			"City" : "\u02bb",
			"Country" : "Tonga",
			"Notes" : ""
		},
		{
			"City" : "Nuuk",
			"Country" : "Greenland",
			"Notes" : "Constituent country Kingdom of Denmark"
		},
		{
			"City" : "Oranjestad",
			"Country" : "Aruba",
			"Notes" : "Kingdom of the Netherlands"
		},
		{
			"City" : "Oslo",
			"Country" : "Norway",
			"Notes" : ""
		},
		{
			"City" : "Ottawa",
			"Country" : "Canada",
			"Notes" : ""
		},
		{
			"City" : "Ouagadougou",
			"Country" : "Burkina Faso",
			"Notes" : ""
		},
		{
			"City" : "Pago Pago",
			"Country" : "American Samoa",
			"Notes" : "Territory United States"
		},
		{
			"City" : "Palikir",
			"Country" : "Federated States of Micronesia",
			"Notes" : ""
		},
		{
			"City" : "Panama City",
			"Country" : "Panama",
			"Notes" : ""
		},
		{
			"City" : "Papeete",
			"Country" : "French Polynesia",
			"Notes" : "Overseas collectivity France"
		},
		{
			"City" : "Paramaribo",
			"Country" : "Suriname",
			"Notes" : ""
		},
		{
			"City" : "Paris",
			"Country" : "France",
			"Notes" : ""
		},
		{
			"City" : "Philipsburg",
			"Country" : "Sint Maarten",
			"Notes" : "Kingdom of the Netherlands"
		},
		{
			"City" : "Phnom Penh",
			"Country" : "Cambodia",
			"Notes" : ""
		},
		{
			"City" : "Plymouth",
			"Country" : "Montserrat",
			"Notes" : "British Overseas Territory"
		},
		{
			"City" : "Podgorica",
			"Country" : "Montenegro",
			"Notes" : ""
		},
		{
			"City" : "Port Louis",
			"Country" : "Mauritius",
			"Notes" : ""
		},
		{
			"City" : "Port Moresby",
			"Country" : "Papua New Guinea",
			"Notes" : ""
		},
		{
			"City" : "Port Vila",
			"Country" : "Vanuatu",
			"Notes" : ""
		},
		{
			"City" : "Port-au-Prince",
			"Country" : "Haiti",
			"Notes" : ""
		},
		{
			"City" : "Port of Spain",
			"Country" : "Trinidad and Tobago",
			"Notes" : ""
		},
		{
			"City" : "Porto-Novo",
			"Country" : "Benin",
			"Notes" : ""
		},
		{
			"City" : "Prague",
			"Country" : "Czech Republic",
			"Notes" : ""
		},
		{
			"City" : "Praia",
			"Country" : "Cape Verde",
			"Notes" : ""
		},
		{
			"City" : "Pretoria",
			"Country" : "South Africa",
			"Notes" : ""
		},
		{
			"City" : "Pristina",
			"Country" : "Kosovo",
			"Notes" : "77 Taiwan (Republic of China) Autonomous Province of Kosovo and Metohija de facto North Kosovo"
		},
		{
			"City" : "Pyongyang",
			"Country" : "North Korea",
			"Notes" : ""
		},
		{
			"City" : "Quito",
			"Country" : "Ecuador",
			"Notes" : ""
		},
		{
			"City" : "Rabat",
			"Country" : "Morocco",
			"Notes" : ""
		},
		{
			"City" : "Reykjav\u00edk",
			"Country" : "Iceland",
			"Notes" : ""
		},
		{
			"City" : "Riga",
			"Country" : "Latvia",
			"Notes" : ""
		},
		{
			"City" : "Riyadh",
			"Country" : "Saudi Arabia",
			"Notes" : ""
		},
		{
			"City" : "Road Town",
			"Country" : "British Virgin Islands",
			"Notes" : "British Overseas Territory"
		},
		{
			"City" : "Rome",
			"Country" : "Italy",
			"Notes" : ""
		},
		{
			"City" : "Roseau",
			"Country" : "Dominica",
			"Notes" : ""
		},
		{
			"City" : "Saipan",
			"Country" : "Northern Mariana Islands",
			"Notes" : "Territory United States"
		},
		{
			"City" : "San Jos\u00e9",
			"Country" : "Costa Rica",
			"Notes" : ""
		},
		{
			"City" : "San Juan",
			"Country" : "Puerto Rico",
			"Notes" : "Territory United States"
		},
		{
			"City" : "San Marino",
			"Country" : "San Marino",
			"Notes" : ""
		},
		{
			"City" : "San Salvador",
			"Country" : "El Salvador",
			"Notes" : ""
		},
		{
			"City" : "Sana\u00e1",
			"Country" : "Yemen",
			"Notes" : ""
		},
		{
			"City" : "Santiago",
			"Country" : "Chile",
			"Notes" : ""
		},
		{
			"City" : "Santo Domingo",
			"Country" : "Dominican Republic",
			"Notes" : ""
		},
		{
			"City" : "S\u00e3o Tom\u00e9",
			"Country" : "S\u00e3o Tom\u00e9 and Pr\u00edncipe",
			"Notes" : ""
		},
		{
			"City" : "Sarajevo",
			"Country" : "Bosnia and Herzegovina",
			"Notes" : ""
		},
		{
			"City" : "Seoul",
			"Country" : "South Korea",
			"Notes" : ""
		},
		{
			"City" : "Singapore",
			"Country" : "Singapore",
			"Notes" : ""
		},
		{
			"City" : "Skopje",
			"Country" : "Macedonia",
			"Notes" : ""
		},
		{
			"City" : "Sofia",
			"Country" : "Bulgaria",
			"Notes" : ""
		},
		{
			"City" : "Sri Jayawardenapura Kotte",
			"Country" : "Sri Lanka",
			"Notes" : ""
		},
		{
			"City" : "St. George's",
			"Country" : "Grenada",
			"Notes" : ""
		},
		{
			"City" : "St. Helier",
			"Country" : "Jersey",
			"Notes" : "Crown Dependency"
		},
		{
			"City" : "St. John's",
			"Country" : "Antigua and Barbuda",
			"Notes" : ""
		},
		{
			"City" : "St. Peter Port",
			"Country" : "Guernsey",
			"Notes" : "Crown Dependency"
		},
		{
			"City" : "St. Pierre",
			"Country" : "Saint Pierre and Miquelon",
			"Notes" : "Overseas collectivity France"
		},
		{
			"City" : "Stanley",
			"Country" : "Falkland Islands",
			"Notes" : "British Overseas Territory"
		},
		{
			"City" : "Stepanakert",
			"Country" : "Nagorno-Karabakh Republic",
			"Notes" : ""
		},
		{
			"City" : "Stockholm",
			"Country" : "Sweden",
			"Notes" : ""
		},
		{
			"City" : "Sucre",
			"Country" : "Bolivia",
			"Notes" : ""
		},
		{
			"City" : "Sukhumi",
			"Country" : "Abkhazia",
			"Notes" : "Republic of Georgia Autonomous Republic of Abkhazia"
		},
		{
			"City" : "Suva",
			"Country" : "Fiji",
			"Notes" : ""
		},
		{
			"City" : "Taipei",
			"Country" : "Republic of China Taiwan",
			"Notes" : "People's Republic of China China Taiwan Spratly Islands   World Health Organization World Trade Organization International Olympic Committee Chinese Taipei"
		},
		{
			"City" : "Tallinn",
			"Country" : "Estonia",
			"Notes" : ""
		},
		{
			"City" : "Tarawa",
			"Country" : "Kiribati",
			"Notes" : ""
		},
		{
			"City" : "Tashkent",
			"Country" : "Uzbekistan",
			"Notes" : ""
		},
		{
			"City" : "Tbilisi",
			"Country" : "Georgia",
			"Notes" : ""
		},
		{
			"City" : "Tegucigalpa",
			"Country" : "Honduras",
			"Notes" : ""
		},
		{
			"City" : "Tehran",
			"Country" : "Iran",
			"Notes" : ""
		},
		{
			"City" : "Thimphu",
			"Country" : "Bhutan",
			"Notes" : ""
		},
		{
			"City" : "Tirana",
			"Country" : "Albania",
			"Notes" : ""
		},
		{
			"City" : "Tiraspol",
			"Country" : "Transnistria",
			"Notes" : "Republic of Moldova Territorial Unit of Transnistria"
		},
		{
			"City" : "Tokyo",
			"Country" : "Japan",
			"Notes" : ""
		},
		{
			"City" : "T\u00f3rshavn",
			"Country" : "Faroe Islands",
			"Notes" : "Constituent country Kingdom of Denmark"
		},
		{
			"City" : "Tripoli",
			"Country" : "Libya",
			"Notes" : ""
		},
		{
			"City" : "Tskhinvali",
			"Country" : "South Ossetia",
			"Notes" : "Republic of Georgia Provisional Administrative Entity of South Ossetia"
		}, {
			"City" : "Tunis",
			"Country" : "Tunisia",
			"Notes" : ""
		}, {
			"City" : "Ulaanbaatar",
			"Country" : "Mongolia",
			"Notes" : ""
		}, {
			"City" : "Vaduz",
			"Country" : "Liechtenstein",
			"Notes" : ""
		}, {
			"City" : "Valletta",
			"Country" : "Malta",
			"Notes" : ""
		}, {
			"City" : "The Valley",
			"Country" : "Anguilla",
			"Notes" : "British Overseas Territory"
		}, {
			"City" : "Vatican City",
			"Country" : "Vatican City",
			"Notes" : ""
		}, {
			"City" : "Victoria",
			"Country" : "Seychelles",
			"Notes" : ""
		}, {
			"City" : "Vienna",
			"Country" : "Austria",
			"Notes" : ""
		}, {
			"City" : "Vientiane",
			"Country" : "Laos",
			"Notes" : ""
		}, {
			"City" : "Vilnius",
			"Country" : "Lithuania",
			"Notes" : ""
		}, {
			"City" : "Warsaw",
			"Country" : "Poland",
			"Notes" : ""
		}, {
			"City" : "Washington, D.C.",
			"Country" : "United States",
			"Notes" : ""
		}, {
			"City" : "Wellington",
			"Country" : "New Zealand",
			"Notes" : ""
		}, {
			"City" : "West Island",
			"Country" : "Cocos (Keeling) Islands",
			"Notes" : "External territory Australia"
		}, {
			"City" : "Willemstad",
			"Country" : "Cura\u00e7ao",
			"Notes" : "Kingdom of the Netherlands"
		}, {
			"City" : "Windhoek",
			"Country" : "Namibia",
			"Notes" : ""
		}, {
			"City" : "Yamoussoukro",
			"Country" : "C\u00f4te d'Ivoire",
			"Notes" : ""
		}, {
			"City" : "Yaound\u00e9",
			"Country" : "Cameroon",
			"Notes" : ""
		}, {
			"City" : "Yaren",
			"Country" : "Nauru",
			"Notes" : ""
		}, {
			"City" : "Yerevan",
			"Country" : "Armenia",
			"Notes" : ""
		}, {
			"City" : "Zagreb",
			"Country" : "Croatia",
			"Notes" : ""
		} ]