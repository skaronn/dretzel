[ {
	"Code" : "+358",
	"Country" : "Finland"
}, {
	"Code" : "+54",
	"Country" : "Argentina"
}, {
	"Code" : "+1",
	"Country" : "United States"
}, {
	"Code" : "+598",
	"Country" : "Uruguay"
}, {
	"Code" : "+81",
	"Country" : "Japan"
}, {
	"Code" : "+56",
	"Country" : "Chile"
}, {
	"Code" : "+54",
	"Country" : "Argentina"
}, {
	"Code" : "+7",
	"Country" : "Russia"
}, {
	"Code" : "+56",
	"Country" : "Chile"
}, {
	"Code" : "+1",
	"Country" : "United States"
}, {
	"Code" : "+56",
	"Country" : "Chile"
}, {
	"Code" : "+672",
	"Country" : "Australia"
}, {
	"Code" : "+55",
	"Country" : "Brazil"
}, {
	"Code" : "",
	"Country" : "Italy   France"
}, {
	"Code" : "+91 (Abandoned)",
	"Country" : "India"
}, {
	"Code" : "+672",
	"Country" : "Australia"
}, {
	"Code" : "+81",
	"Country" : "Japan"
}, {
	"Code" : "+33",
	"Country" : "France"
}, {
	"Code" : "+54",
	"Country" : "Argentina"
}, {
	"Code" : "+34",
	"Country" : "Spain"
}, {
	"Code" : "Neumayer Station",
	"Country" : "Germany"
}, {
	"Code" : "+56",
	"Country" : "Chile"
}, {
	"Code" : "+86",
	"Country" : "China"
}, {
	"Code" : "+44",
	"Country" : "United Kingdom"
}, {
	"Code" : "+48",
	"Country" : "Poland"
}, {
	"Code" : "+92",
	"Country" : "Pakistan"
}, {
	"Code" : "+34",
	"Country" : "Spain"
}, {
	"Code" : "+54",
	"Country" : "Argentina"
}, {
	"Code" : "+82",
	"Country" : "South Korea"
}, {
	"Code" : "+49",
	"Country" : "Germany"
}, {
	"Code" : "+86",
	"Country" : "China"
}, {
	"Code" : "+40",
	"Country" : "Romania"
}, {
	"Code" : "+7",
	"Country" : "Russia"
}, {
	"Code" : "+51",
	"Country" : "Peru"
}, {
	"Code" : "+672",
	"Country" : "Australia"
}, {
	"Code" : "+91",
	"Country" : "India"
}, {
	"Code" : "+54",
	"Country" : "Argentina"
}, {
	"Code" : "+39",
	"Country" : "Italy"
}, {
	"Code" : "+672",
	"Country" : "Australia"
}, {
	"Code" : "+1",
	"Country" : "United States"
}, {
	"Code" : "+420",
	"Country" : "Czech Republic"
}, {
	"Code" : "+7",
	"Country" : "Russia"
}, {
	"Code" : "+81",
	"Country" : "Japan"
}, {
	"Code" : "",
	"Country" : "Russia   Belarus"
}, {
	"Code" : "+49",
	"Country" : "Germany"
}, {
	"Code" : "+7",
	"Country" : "Russia"
}, {
	"Code" : "+54",
	"Country" : "Argentina"
}, {
	"Code" : "+1",
	"Country" : "United States"
}, {
	"Code" : "+32",
	"Country" : "Belgium"
}, {
	"Code" : "+56",
	"Country" : "Chile"
}, {
	"Code" : "+7",
	"Country" : "Russia"
}, {
	"Code" : "+44",
	"Country" : "United Kingdom"
}, {
	"Code" : "+7",
	"Country" : "Russia"
}, {
	"Code" : "+54",
	"Country" : "Argentina"
}, {
	"Code" : "+27",
	"Country" : "South Africa"
}, {
	"Code" : "+44",
	"Country" : "United Kingdom"
}, {
	"Code" : "+359",
	"Country" : "Bulgaria"
}, {
	"Code" : "+64",
	"Country" : "New Zealand"
}, {
	"Code" : "+81",
	"Country" : "Japan"
}, {
	"Code" : "+46",
	"Country" : "Sweden"
}, {
	"Code" : "+47",
	"Country" : "Norway"
}, {
	"Code" : "+47",
	"Country" : "Norway"
}, {
	"Code" : "+46",
	"Country" : "Sweden"
}, {
	"Code" : "+7",
	"Country" : "Russia"
}, {
	"Code" : "+380",
	"Country" : "Ukraine"
}, {
	"Code" : "+86",
	"Country" : "China"
} ]