[
		{
			"name" : "Russian ruble",
			"simbol" : "\u0440.",
			"code" : "RUB",
			"fractionalUnit" : "Kopek",
			"countries" : [ "Russia", "South Ossetia" ]
		},
		{
			"name" : "Afghan afghani",
			"simbol" : "\u060b",
			"code" : "AFN",
			"fractionalUnit" : "Pul",
			"countries" : [ "Afghanistan" ]
		},
		{
			"name" : "Euro",
			"simbol" : "\u20ac",
			"code" : "EUR",
			"fractionalUnit" : "Cent",
			"countries" : [ "Akrotiri and Dhekelia", "Andorra", "Austria",
					"Belgium", "Cyprus", "Estonia", "Finland", "France",
					"Germany", "Greece", "Ireland", "Italy", "Kosovo",
					"Luxembourg", "Malta", "Monaco", "Montenegro",
					"Netherlands", "Portugal", "San Marino", "Slovakia",
					"Slovenia", "Spain", "Vatican City" ]
		},
		{
			"name" : "Albanian lek",
			"simbol" : "L",
			"code" : "ALL",
			"fractionalUnit" : "Qindark\u00eb",
			"countries" : [ "Albania" ]
		},
		{
			"name" : "British pound",
			"simbol" : "\u00a3",
			"code" : "GBP",
			"fractionalUnit" : "Penny",
			"countries" : [ "Guernsey", "Isle of Man", "Jersey",
					"South Georgia and the South Sandwich Islands",
					"United Kingdom" ]
		},
		{
			"name" : "Algerian dinar",
			"simbol" : "\u062f.\u062c",
			"code" : "DZD",
			"fractionalUnit" : "Santeem",
			"countries" : [ "Algeria" ]
		},
		{
			"name" : "Angolan kwanza",
			"simbol" : "Kz",
			"code" : "AOA",
			"fractionalUnit" : "C\u00eantimo",
			"countries" : [ "Angola" ]
		},
		{
			"name" : "East Caribbean dollar",
			"simbol" : "$",
			"code" : "XCD",
			"fractionalUnit" : "Cent",
			"countries" : [ "Anguilla", "Antigua and Barbuda", "Dominica",
					"Grenada", "Montserrat", "Saint Kitts and Nevis",
					"Saint Lucia", "Saint Vincent and the Grenadines" ]
		},
		{
			"name" : "Argentine peso",
			"simbol" : "$",
			"code" : "ARS",
			"fractionalUnit" : "Centavo",
			"countries" : [ "Argentina" ]
		},
		{
			"name" : "Armenian dram",
			"simbol" : "\u0564\u0580.",
			"code" : "AMD",
			"fractionalUnit" : "Luma",
			"countries" : [ "Armenia", "Nagorno-Karabakh Republic" ]
		},
		{
			"name" : "Aruban florin",
			"simbol" : "\u0192",
			"code" : "AWG",
			"fractionalUnit" : "Cent",
			"countries" : [ "Aruba" ]
		},
		{
			"name" : "Saint Helena pound",
			"simbol" : "\u00a3",
			"code" : "SHP",
			"fractionalUnit" : "Penny",
			"countries" : [ "Saint Helena", "Tristan da Cunha" ]
		},
		{
			"name" : "Australian dollar",
			"simbol" : "$",
			"code" : "AUD",
			"fractionalUnit" : "Cent",
			"countries" : [ "Australia", "Cocos (Keeling) Islands", "Kiribati",
					"Nauru", "Tuvalu" ]
		},
		{
			"name" : "Azerbaijani manat",
			"simbol" : "",
			"code" : "AZN",
			"fractionalUnit" : "Q\u0259pik",
			"countries" : [ "Azerbaijan" ]
		},
		{
			"name" : "Bahamian dollar",
			"simbol" : "$",
			"code" : "BSD",
			"fractionalUnit" : "Cent",
			"countries" : [ "Bahamas" ]
		},
		{
			"name" : "Bahraini dinar",
			"simbol" : ".\u062f.\u0628",
			"code" : "BHD",
			"fractionalUnit" : "Fils",
			"countries" : [ "Bahrain" ]
		},
		{
			"name" : "Bangladeshi taka",
			"simbol" : "\u09f3",
			"code" : "BDT",
			"fractionalUnit" : "Paisa",
			"countries" : [ "Bangladesh" ]
		},
		{
			"name" : "Barbadian dollar",
			"simbol" : "$",
			"code" : "BBD",
			"fractionalUnit" : "Cent",
			"countries" : [ "Barbados" ]
		},
		{
			"name" : "Belarusian ruble",
			"simbol" : "Br",
			"code" : "BYR",
			"fractionalUnit" : "Kapyeyka",
			"countries" : [ "Belarus" ]
		},
		{
			"name" : "Belize dollar",
			"simbol" : "$",
			"code" : "BZD",
			"fractionalUnit" : "Cent",
			"countries" : [ "Belize" ]
		},
		{
			"name" : "West African CFA franc",
			"simbol" : "Fr",
			"code" : "XOF",
			"fractionalUnit" : "Centime",
			"countries" : [ "Benin", "Burkina Faso", "C\u00f4te d'Ivoire",
					"Guinea-Bissau", "Mali", "Niger", "Senegal", "Togo" ]
		},
		{
			"name" : "Bermudian dollar",
			"simbol" : "$",
			"code" : "BMD",
			"fractionalUnit" : "Cent",
			"countries" : [ "Bermuda" ]
		},
		{
			"name" : "Bhutanese ngultrum",
			"simbol" : "Nu.",
			"code" : "BTN",
			"fractionalUnit" : "Chetrum",
			"countries" : [ "Bhutan" ]
		},
		{
			"name" : "Indian rupee",
			"simbol" : "\u20b9",
			"code" : "INR",
			"fractionalUnit" : "Paisa",
			"countries" : [ "India" ]
		},
		{
			"name" : "Bolivian boliviano",
			"simbol" : "Bs.",
			"code" : "BOB",
			"fractionalUnit" : "Centavo",
			"countries" : [ "Bolivia" ]
		},
		{
			"name" : "United States dollar",
			"simbol" : "$",
			"code" : "USD",
			"fractionalUnit" : "Cent",
			"countries" : [ "Bonaire", "British Indian Ocean Territory",
					"East Timor", "Ecuador", "Marshall Islands", "Saba",
					"Sint Eustatius", "Turks and Caicos Islands",
					"United States" ]
		},
		{
			"name" : "Bosnia and Herzegovina convertible mark",
			"simbol" : "KM or \u041a\u041c",
			"code" : "BAM",
			"fractionalUnit" : "Fening",
			"countries" : [ "Bosnia and Herzegovina" ]
		},
		{
			"name" : "Botswana pula",
			"simbol" : "P",
			"code" : "BWP",
			"fractionalUnit" : "Thebe",
			"countries" : [ "Botswana", "Zimbabwe" ]
		},
		{
			"name" : "Brazilian real",
			"simbol" : "R$",
			"code" : "BRL",
			"fractionalUnit" : "Centavo",
			"countries" : [ "Brazil" ]
		},
		{
			"name" : "Brunei dollar",
			"simbol" : "$",
			"code" : "BND",
			"fractionalUnit" : "Sen",
			"countries" : [ "Brunei", "Singapore" ]
		},
		{
			"name" : "Singapore dollar",
			"simbol" : "$",
			"code" : "SGD",
			"fractionalUnit" : "Cent",
			"countries" : []
		},
		{
			"name" : "Bulgarian lev",
			"simbol" : "\u043b\u0432",
			"code" : "BGN",
			"fractionalUnit" : "Stotinka",
			"countries" : [ "Bulgaria" ]
		},
		{
			"name" : "Myanma kyat",
			"simbol" : "K",
			"code" : "MMK",
			"fractionalUnit" : "Pya",
			"countries" : [ "Burma" ]
		},
		{
			"name" : "Burundian franc",
			"simbol" : "Fr",
			"code" : "BIF",
			"fractionalUnit" : "Centime",
			"countries" : [ "Burundi" ]
		},
		{
			"name" : "Cambodian riel",
			"simbol" : "\u17db",
			"code" : "KHR",
			"fractionalUnit" : "Sen",
			"countries" : [ "Cambodia" ]
		},
		{
			"name" : "Central African CFA franc",
			"simbol" : "Fr",
			"code" : "XAF",
			"fractionalUnit" : "Centime",
			"countries" : [ "Cameroon", "Central African Republic", "Chad",
					"Congo, Republic of the", "Equatorial Guinea", "Gabon" ]
		},
		{
			"name" : "Canadian dollar",
			"simbol" : "$",
			"code" : "CAD",
			"fractionalUnit" : "Cent",
			"countries" : [ "Canada" ]
		},
		{
			"name" : "Cape Verdean escudo",
			"simbol" : "Esc or $",
			"code" : "CVE",
			"fractionalUnit" : "Centavo",
			"countries" : [ "Cape Verde" ]
		},
		{
			"name" : "Cayman Islands dollar",
			"simbol" : "$",
			"code" : "KYD",
			"fractionalUnit" : "Cent",
			"countries" : [ "Cayman Islands" ]
		},
		{
			"name" : "Chilean peso",
			"simbol" : "$",
			"code" : "CLP",
			"fractionalUnit" : "Centavo",
			"countries" : [ "Chile" ]
		},
		{
			"name" : "Chinese yuan",
			"simbol" : "\u00a5 or \u5143",
			"code" : "CNY",
			"fractionalUnit" : "Fen",
			"countries" : [ "China" ]
		},
		{
			"name" : "Colombian peso",
			"simbol" : "$",
			"code" : "COP",
			"fractionalUnit" : "Centavo",
			"countries" : [ "Colombia" ]
		},
		{
			"name" : "Comorian franc",
			"simbol" : "Fr",
			"code" : "KMF",
			"fractionalUnit" : "Centime",
			"countries" : [ "Comoros" ]
		},
		{
			"name" : "Congolese franc",
			"simbol" : "Fr",
			"code" : "CDF",
			"fractionalUnit" : "Centime",
			"countries" : [ "Congo, Democratic Republic of the" ]
		},
		{
			"name" : "New Zealand dollar",
			"simbol" : "$",
			"code" : "NZD",
			"fractionalUnit" : "Cent",
			"countries" : [ "Cook Islands", "New Zealand", "Niue",
					"Pitcairn Islands" ]
		},
		{
			"name" : "Costa Rican col\u00f3n",
			"simbol" : "\u20a1",
			"code" : "CRC",
			"fractionalUnit" : "C\u00e9ntimo",
			"countries" : [ "Costa Rica" ]
		},
		{
			"name" : "Croatian kuna",
			"simbol" : "kn",
			"code" : "HRK",
			"fractionalUnit" : "Lipa",
			"countries" : [ "Croatia" ]
		},
		{
			"name" : "Cuban convertible peso",
			"simbol" : "$",
			"code" : "CUC",
			"fractionalUnit" : "Centavo",
			"countries" : [ "Cuba" ]
		},
		{
			"name" : "Cuban peso",
			"simbol" : "$",
			"code" : "CUP",
			"fractionalUnit" : "Centavo",
			"countries" : []
		},
		{
			"name" : "Netherlands Antillean guilder",
			"simbol" : "\u0192",
			"code" : "ANG",
			"fractionalUnit" : "Cent",
			"countries" : [ "Cura\u00e7ao", "Sint Maarten" ]
		},
		{
			"name" : "Czech koruna",
			"simbol" : "K\u010d",
			"code" : "CZK",
			"fractionalUnit" : "Hal\u00e9\u0159",
			"countries" : [ "Czech Republic" ]
		},
		{
			"name" : "Danish krone",
			"simbol" : "kr",
			"code" : "DKK",
			"fractionalUnit" : "\u00d8re",
			"countries" : [ "Denmark", "Faroe Islands" ]
		},
		{
			"name" : "Djiboutian franc",
			"simbol" : "Fr",
			"code" : "DJF",
			"fractionalUnit" : "Centime",
			"countries" : [ "Djibouti" ]
		},
		{
			"name" : "Dominican peso",
			"simbol" : "$",
			"code" : "DOP",
			"fractionalUnit" : "Centavo",
			"countries" : [ "Dominican Republic" ]
		},
		{
			"name" : "Egyptian pound",
			"simbol" : "\u00a3 or \u062c.\u0645",
			"code" : "EGP",
			"fractionalUnit" : "piaster",
			"countries" : [ "Egypt" ]
		},
		{
			"name" : "Salvadoran col\u00f3n",
			"simbol" : "\u20a1",
			"code" : "SVC",
			"fractionalUnit" : "Centavo",
			"countries" : [ "El Salvador" ]
		},
		{
			"name" : "Eritrean nakfa",
			"simbol" : "Nfk",
			"code" : "ERN",
			"fractionalUnit" : "Cent",
			"countries" : [ "Eritrea" ]
		},
		{
			"name" : "Ethiopian birr",
			"simbol" : "Br",
			"code" : "ETB",
			"fractionalUnit" : "Santim",
			"countries" : [ "Ethiopia" ]
		},
		{
			"name" : "Falkland Islands pound",
			"simbol" : "\u00a3",
			"code" : "FKP",
			"fractionalUnit" : "Penny",
			"countries" : [ "Falkland Islands" ]
		},
		{
			"name" : "Fijian dollar",
			"simbol" : "$",
			"code" : "FJD",
			"fractionalUnit" : "Cent",
			"countries" : [ "Fiji" ]
		},
		{
			"name" : "CFP franc",
			"simbol" : "Fr",
			"code" : "XPF",
			"fractionalUnit" : "Centime",
			"countries" : [ "French Polynesia", "New Caledonia",
					"Wallis and Futuna" ]
		}, {
			"name" : "Gambian dalasi",
			"simbol" : "D",
			"code" : "GMD",
			"fractionalUnit" : "Butut",
			"countries" : [ "Gambia" ]
		}, {
			"name" : "Georgian lari",
			"simbol" : "\u10da",
			"code" : "GEL",
			"fractionalUnit" : "Tetri",
			"countries" : [ "Georgia" ]
		}, {
			"name" : "Ghanaian cedi",
			"simbol" : "\u20b5",
			"code" : "GHS",
			"fractionalUnit" : "Pesewa",
			"countries" : [ "Ghana" ]
		}, {
			"name" : "Gibraltar pound",
			"simbol" : "\u00a3",
			"code" : "GIP",
			"fractionalUnit" : "Penny",
			"countries" : [ "Gibraltar" ]
		}, {
			"name" : "Guatemalan quetzal",
			"simbol" : "Q",
			"code" : "GTQ",
			"fractionalUnit" : "Centavo",
			"countries" : [ "Guatemala" ]
		}, {
			"name" : "Guinean franc",
			"simbol" : "Fr",
			"code" : "GNF",
			"fractionalUnit" : "Centime",
			"countries" : [ "Guinea" ]
		}, {
			"name" : "Guyanese dollar",
			"simbol" : "$",
			"code" : "GYD",
			"fractionalUnit" : "Cent",
			"countries" : [ "Guyana" ]
		}, {
			"name" : "Haitian gourde",
			"simbol" : "G",
			"code" : "HTG",
			"fractionalUnit" : "Centime",
			"countries" : [ "Haiti" ]
		}, {
			"name" : "Honduran lempira",
			"simbol" : "L",
			"code" : "HNL",
			"fractionalUnit" : "Centavo",
			"countries" : [ "Honduras" ]
		}, {
			"name" : "Hong Kong dollar",
			"simbol" : "$",
			"code" : "HKD",
			"fractionalUnit" : "Cent",
			"countries" : [ "Hong Kong" ]
		}, {
			"name" : "Hungarian forint",
			"simbol" : "Ft",
			"code" : "HUF",
			"fractionalUnit" : "Fill\u00e9r",
			"countries" : [ "Hungary" ]
		}, {
			"name" : "Icelandic kr\u00f3na",
			"simbol" : "kr",
			"code" : "ISK",
			"fractionalUnit" : "Eyrir",
			"countries" : [ "Iceland" ]
		}, {
			"name" : "Indonesian rupiah",
			"simbol" : "Rp",
			"code" : "IDR",
			"fractionalUnit" : "Sen",
			"countries" : [ "Indonesia" ]
		}, {
			"name" : "Iranian rial",
			"simbol" : "\ufdfc",
			"code" : "IRR",
			"fractionalUnit" : "Dinar",
			"countries" : [ "Iran" ]
		}, {
			"name" : "Iraqi dinar",
			"simbol" : "\u0639.\u062f",
			"code" : "IQD",
			"fractionalUnit" : "Fils",
			"countries" : [ "Iraq" ]
		}, {
			"name" : "Israeli new shekel",
			"simbol" : "\u20aa",
			"code" : "ILS",
			"fractionalUnit" : "Agora",
			"countries" : [ "Israel", "Palestine" ]
		}, {
			"name" : "Jamaican dollar",
			"simbol" : "$",
			"code" : "JMD",
			"fractionalUnit" : "Cent",
			"countries" : [ "Jamaica" ]
		}, {
			"name" : "Japanese yen",
			"simbol" : "\u00a5",
			"code" : "JPY",
			"fractionalUnit" : "Sen",
			"countries" : [ "Japan" ]
		}, {
			"name" : "Jordanian dinar",
			"simbol" : "\u062f.\u0627",
			"code" : "JOD",
			"fractionalUnit" : "fils",
			"countries" : [ "Jordan" ]
		}, {
			"name" : "Kazakhstani tenge",
			"simbol" : "\u20b8",
			"code" : "KZT",
			"fractionalUnit" : "T\u00ef\u0131n",
			"countries" : [ "Kazakhstan" ]
		}, {
			"name" : "Kenyan shilling",
			"simbol" : "Sh",
			"code" : "KES",
			"fractionalUnit" : "Cent",
			"countries" : [ "Kenya" ]
		}, {
			"name" : "North Korean won",
			"simbol" : "\u20a9",
			"code" : "KPW",
			"fractionalUnit" : "Chon",
			"countries" : [ "North Korea" ]
		}, {
			"name" : "South Korean won",
			"simbol" : "\u20a9",
			"code" : "KRW",
			"fractionalUnit" : "Jeon",
			"countries" : [ "South Korea" ]
		}, {
			"name" : "Kuwaiti dinar",
			"simbol" : "\u062f.\u0643",
			"code" : "KWD",
			"fractionalUnit" : "Fils",
			"countries" : [ "Kuwait" ]
		}, {
			"name" : "Kyrgyzstani som",
			"simbol" : "\u043b\u0432",
			"code" : "KGS",
			"fractionalUnit" : "Tyiyn",
			"countries" : [ "Kyrgyzstan" ]
		}, {
			"name" : "Lao kip",
			"simbol" : "\u20ad",
			"code" : "LAK",
			"fractionalUnit" : "Att",
			"countries" : [ "Laos" ]
		}, {
			"name" : "Latvian lats",
			"simbol" : "Ls",
			"code" : "LVL",
			"fractionalUnit" : "Sant\u012bms",
			"countries" : [ "Latvia" ]
		}, {
			"name" : "Lebanese pound",
			"simbol" : "\u0644.\u0644",
			"code" : "LBP",
			"fractionalUnit" : "Piastre",
			"countries" : [ "Lebanon" ]
		}, {
			"name" : "Lesotho loti",
			"simbol" : "L",
			"code" : "LSL",
			"fractionalUnit" : "Sente",
			"countries" : [ "Lesotho" ]
		}, {
			"name" : "South African rand",
			"simbol" : "R",
			"code" : "ZAR",
			"fractionalUnit" : "Cent",
			"countries" : [ "South Africa" ]
		}, {
			"name" : "Liberian dollar",
			"simbol" : "$",
			"code" : "LRD",
			"fractionalUnit" : "Cent",
			"countries" : [ "Liberia" ]
		}, {
			"name" : "Libyan dinar",
			"simbol" : "\u0644.\u062f",
			"code" : "LYD",
			"fractionalUnit" : "Dirham",
			"countries" : [ "Libya" ]
		}, {
			"name" : "Swiss franc",
			"simbol" : "Fr",
			"code" : "CHF",
			"fractionalUnit" : "Rappen",
			"countries" : [ "Liechtenstein", "Switzerland" ]
		}, {
			"name" : "Lithuanian litas",
			"simbol" : "Lt",
			"code" : "LTL",
			"fractionalUnit" : "Centas",
			"countries" : [ "Lithuania" ]
		}, {
			"name" : "Macanese pataca",
			"simbol" : "P",
			"code" : "MOP",
			"fractionalUnit" : "Avo",
			"countries" : [ "Macau" ]
		}, {
			"name" : "Macedonian denar",
			"simbol" : "\u0434\u0435\u043d",
			"code" : "MKD",
			"fractionalUnit" : "Deni",
			"countries" : [ "Macedonia" ]
		}, {
			"name" : "Malagasy ariary",
			"simbol" : "Ar",
			"code" : "MGA",
			"fractionalUnit" : "Iraimbilanja",
			"countries" : [ "Madagascar" ]
		}, {
			"name" : "Malawian kwacha",
			"simbol" : "MK",
			"code" : "MWK",
			"fractionalUnit" : "Tambala",
			"countries" : [ "Malawi" ]
		}, {
			"name" : "Malaysian ringgit",
			"simbol" : "RM",
			"code" : "MYR",
			"fractionalUnit" : "Sen",
			"countries" : [ "Malaysia" ]
		}, {
			"name" : "Maldivian rufiyaa",
			"simbol" : "\u0783.",
			"code" : "MVR",
			"fractionalUnit" : "Laari",
			"countries" : [ "Maldives" ]
		}, {
			"name" : "Mauritanian ouguiya",
			"simbol" : "UM",
			"code" : "MRO",
			"fractionalUnit" : "Khoums",
			"countries" : [ "Mauritania" ]
		}, {
			"name" : "Mauritian rupee",
			"simbol" : "\u20a8",
			"code" : "MUR",
			"fractionalUnit" : "Cent",
			"countries" : [ "Mauritius" ]
		}, {
			"name" : "Mexican peso",
			"simbol" : "$",
			"code" : "MXN",
			"fractionalUnit" : "Centavo",
			"countries" : [ "Mexico" ]
		}, {
			"name" : "Moldovan leu",
			"simbol" : "L",
			"code" : "MDL",
			"fractionalUnit" : "Ban",
			"countries" : [ "Moldova" ]
		}, {
			"name" : "Mongolian t\u00f6gr\u00f6g",
			"simbol" : "\u20ae",
			"code" : "MNT",
			"fractionalUnit" : "M\u00f6ng\u00f6",
			"countries" : [ "Mongolia" ]
		}, {
			"name" : "Moroccan dirham",
			"simbol" : "\u062f.\u0645.",
			"code" : "MAD",
			"fractionalUnit" : "Centime",
			"countries" : [ "Morocco", "Western Sahara" ]
		}, {
			"name" : "Mozambican metical",
			"simbol" : "MTn",
			"code" : "MZN",
			"fractionalUnit" : "Centavo",
			"countries" : [ "Mozambique" ]
		}, {
			"name" : "Namibian dollar",
			"simbol" : "$",
			"code" : "NAD",
			"fractionalUnit" : "Cent",
			"countries" : [ "Namibia" ]
		}, {
			"name" : "Nepalese rupee",
			"simbol" : "\u20a8",
			"code" : "NPR",
			"fractionalUnit" : "Paisa",
			"countries" : [ "Nepal" ]
		}, {
			"name" : "Nicaraguan c\u00f3rdoba",
			"simbol" : "C$",
			"code" : "NIO",
			"fractionalUnit" : "Centavo",
			"countries" : [ "Nicaragua" ]
		}, {
			"name" : "Nigerian naira",
			"simbol" : "\u20a6",
			"code" : "NGN",
			"fractionalUnit" : "Kobo",
			"countries" : [ "Nigeria" ]
		}, {
			"name" : "Turkish lira",
			"simbol" : "TL",
			"code" : "TRY",
			"fractionalUnit" : "Kuru\u015f",
			"countries" : [ "Northern Cyprus", "Turkey" ]
		}, {
			"name" : "Norwegian krone",
			"simbol" : "kr",
			"code" : "NOK",
			"fractionalUnit" : "\u00d8re",
			"countries" : [ "Norway" ]
		}, {
			"name" : "Omani rial",
			"simbol" : "\u0631.\u0639.",
			"code" : "OMR",
			"fractionalUnit" : "Baisa",
			"countries" : [ "Oman" ]
		}, {
			"name" : "Pakistani rupee",
			"simbol" : "\u20a8",
			"code" : "PKR",
			"fractionalUnit" : "Paisa",
			"countries" : [ "Pakistan" ]
		}, {
			"name" : "Panamanian balboa",
			"simbol" : "B\/.",
			"code" : "PAB",
			"fractionalUnit" : "Cent\u00e9simo",
			"countries" : [ "Panama" ]
		}, {
			"name" : "Papua New Guinean kina",
			"simbol" : "K",
			"code" : "PGK",
			"fractionalUnit" : "Toea",
			"countries" : [ "Papua New Guinea" ]
		}, {
			"name" : "Paraguayan guaran\u00ed",
			"simbol" : "\u20b2",
			"code" : "PYG",
			"fractionalUnit" : "C\u00e9ntimo",
			"countries" : [ "Paraguay" ]
		}, {
			"name" : "Peruvian nuevo sol",
			"simbol" : "S\/.",
			"code" : "PEN",
			"fractionalUnit" : "C\u00e9ntimo",
			"countries" : [ "Peru" ]
		}, {
			"name" : "Philippine peso",
			"simbol" : "\u20b1",
			"code" : "PHP",
			"fractionalUnit" : "Centavo",
			"countries" : [ "Philippines" ]
		}, {
			"name" : "Polish z\u0142oty",
			"simbol" : "z\u0142",
			"code" : "PLN",
			"fractionalUnit" : "Grosz",
			"countries" : [ "Poland" ]
		}, {
			"name" : "Qatari riyal",
			"simbol" : "\u0631.\u0642",
			"code" : "QAR",
			"fractionalUnit" : "Dirham",
			"countries" : [ "Qatar" ]
		}, {
			"name" : "Romanian leu",
			"simbol" : "L",
			"code" : "RON",
			"fractionalUnit" : "Ban",
			"countries" : [ "Romania" ]
		}, {
			"name" : "Rwandan franc",
			"simbol" : "Fr",
			"code" : "RWF",
			"fractionalUnit" : "Centime",
			"countries" : [ "Rwanda" ]
		}, {
			"name" : "Samoan tala",
			"simbol" : "T",
			"code" : "WST",
			"fractionalUnit" : "Sene",
			"countries" : [ "Samoa" ]
		}, {
			"name" : "S\u00e3o Tom\u00e9 and Pr\u00edncipe dobra",
			"simbol" : "Db",
			"code" : "STD",
			"fractionalUnit" : "C\u00eantimo",
			"countries" : [ "S\u00e3o Tom\u00e9 and Pr\u00edncipe" ]
		}, {
			"name" : "Saudi riyal",
			"simbol" : "\u0631.\u0633",
			"code" : "SAR",
			"fractionalUnit" : "Hallallah",
			"countries" : [ "Saudi Arabia" ]
		}, {
			"name" : "Serbian dinar",
			"simbol" : "\u0434\u0438\u043d. or din.",
			"code" : "RSD",
			"fractionalUnit" : "Para",
			"countries" : [ "Serbia" ]
		}, {
			"name" : "Seychellois rupee",
			"simbol" : "\u20a8",
			"code" : "SCR",
			"fractionalUnit" : "Cent",
			"countries" : [ "Seychelles" ]
		}, {
			"name" : "Sierra Leonean leone",
			"simbol" : "Le",
			"code" : "SLL",
			"fractionalUnit" : "Cent",
			"countries" : [ "Sierra Leone" ]
		}, {
			"name" : "Solomon Islands dollar",
			"simbol" : "$",
			"code" : "SBD",
			"fractionalUnit" : "Cent",
			"countries" : [ "Solomon Islands" ]
		}, {
			"name" : "Somali shilling",
			"simbol" : "Sh",
			"code" : "SOS",
			"fractionalUnit" : "Cent",
			"countries" : [ "Somalia" ]
		}, {
			"name" : "Sudanese pound",
			"simbol" : "\u00a3",
			"code" : "SDG",
			"fractionalUnit" : "Piastre",
			"countries" : [ "South Sudan", "Sudan" ]
		}, {
			"name" : "Sri Lankan rupee",
			"simbol" : "Rs",
			"code" : "LKR",
			"fractionalUnit" : "Cent",
			"countries" : [ "Sri Lanka" ]
		}, {
			"name" : "Surinamese dollar",
			"simbol" : "$",
			"code" : "SRD",
			"fractionalUnit" : "Cent",
			"countries" : [ "Suriname" ]
		}, {
			"name" : "Swazi lilangeni",
			"simbol" : "L",
			"code" : "SZL",
			"fractionalUnit" : "Cent",
			"countries" : [ "Swaziland" ]
		}, {
			"name" : "Swedish krona",
			"simbol" : "kr",
			"code" : "SEK",
			"fractionalUnit" : "\u00d6re",
			"countries" : [ "Sweden" ]
		}, {
			"name" : "Syrian pound",
			"simbol" : "\u00a3 or \u0644.\u0633",
			"code" : "SYP",
			"fractionalUnit" : "Piastre",
			"countries" : [ "Syria" ]
		}, {
			"name" : "New Taiwan dollar",
			"simbol" : "$",
			"code" : "TWD",
			"fractionalUnit" : "Cent",
			"countries" : [ "Taiwan" ]
		}, {
			"name" : "Tajikistani somoni",
			"simbol" : "\u0405\u041c",
			"code" : "TJS",
			"fractionalUnit" : "Diram",
			"countries" : [ "Tajikistan" ]
		}, {
			"name" : "Tanzanian shilling",
			"simbol" : "Sh",
			"code" : "TZS",
			"fractionalUnit" : "Cent",
			"countries" : [ "Tanzania" ]
		}, {
			"name" : "Thai baht",
			"simbol" : "\u0e3f",
			"code" : "THB",
			"fractionalUnit" : "Satang",
			"countries" : [ "Thailand" ]
		}, {
			"name" : "Tongan pa\u02bbanga",
			"simbol" : "T$",
			"code" : "TOP",
			"fractionalUnit" : "Seniti",
			"countries" : [ "Tonga" ]
		}, {
			"name" : "Trinidad and Tobago dollar",
			"simbol" : "$",
			"code" : "TTD",
			"fractionalUnit" : "Cent",
			"countries" : [ "Trinidad and Tobago" ]
		}, {
			"name" : "Tunisian dinar",
			"simbol" : "\u062f.\u062a",
			"code" : "TND",
			"fractionalUnit" : "Millime",
			"countries" : [ "Tunisia" ]
		}, {
			"name" : "Turkmenistani manat",
			"simbol" : "m",
			"code" : "TMT",
			"fractionalUnit" : "Tennesi",
			"countries" : [ "Turkmenistan" ]
		}, {
			"name" : "Ugandan shilling",
			"simbol" : "Sh",
			"code" : "UGX",
			"fractionalUnit" : "Cent",
			"countries" : [ "Uganda" ]
		}, {
			"name" : "Ukrainian hryvnia",
			"simbol" : "\u20b4",
			"code" : "UAH",
			"fractionalUnit" : "Kopiyka",
			"countries" : [ "Ukraine" ]
		}, {
			"name" : "United Arab Emirates dirham",
			"simbol" : "\u062f.\u0625",
			"code" : "AED",
			"fractionalUnit" : "Fils",
			"countries" : [ "United Arab Emirates" ]
		}, {
			"name" : "Uruguayan peso",
			"simbol" : "$",
			"code" : "UYU",
			"fractionalUnit" : "Cent\u00e9simo",
			"countries" : [ "Uruguay" ]
		}, {
			"name" : "Uzbekistani som",
			"simbol" : "\u043b\u0432",
			"code" : "UZS",
			"fractionalUnit" : "Tiyin",
			"countries" : [ "Uzbekistan" ]
		}, {
			"name" : "Vanuatu vatu",
			"simbol" : "Vt",
			"code" : "VUV",
			"fractionalUnit" : false,
			"countries" : [ "Vanuatu" ]
		}, {
			"name" : "Venezuelan bol\u00edvar",
			"simbol" : "Bs F",
			"code" : "VEF",
			"fractionalUnit" : "C\u00e9ntimo",
			"countries" : [ "Venezuela" ]
		}, {
			"name" : "Vietnamese \u0111\u1ed3ng",
			"simbol" : "\u20ab",
			"code" : "VND",
			"fractionalUnit" : "H\u00e0o",
			"countries" : [ "Vietnam" ]
		}, {
			"name" : "Yemeni rial",
			"simbol" : "\ufdfc",
			"code" : "YER",
			"fractionalUnit" : "Fils",
			"countries" : [ "Yemen" ]
		}, {
			"name" : "Zambian kwacha",
			"simbol" : "ZK",
			"code" : "ZMK",
			"fractionalUnit" : "Ngwee",
			"countries" : [ "Zambia" ]
		} ]