package main;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.IllegalFormatException;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.UnknownFormatConversionException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import net.sf.json.JSON;
import net.sf.json.JSONSerializer;
import net.sf.json.xml.XMLSerializer;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.jdbc.ScriptRunner;
import org.apache.log4j.Logger;
import org.apache.log4j.Priority;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.ls.DOMImplementationLS;
import org.w3c.dom.ls.LSOutput;
import org.w3c.dom.ls.LSSerializer;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import au.com.bytecode.opencsv.CSVReader;

import com.esotericsoftware.yamlbeans.YamlException;
import com.esotericsoftware.yamlbeans.YamlReader;

/**
 * This class is a cross data wrapper which transforms any
 * XML, JSON, YAML, CSV/XLS, SQL,  DAT (SQL Server Unicode), ASC (ASCII), 
 * BINARY, HEXADECIMAL,...file in destination format data file
 * <br /><br />
 * 
 * This class uses XML as bridge type for all data type
 * because it's the most common used, powerful and complex type
 * 
 * @author adgnabro
 */
public class CrossDataWrapper
{

	private static final String SAMPLE_BASE_DIRECTORY = "/sample/data/";
	private static final String DESTINATION_DIR = "/output/";
	private static final boolean IS_DEBUG_ENABLED = true;

	private static final Logger LOGGER = Logger.getLogger(CrossDataWrapper.class);

	private enum DataType {
		XML, JSON, CSV, YML, YAML, SQL, DAT, ASC, BIN, BINARY, HEX, HEXADECIMAL, HTML
	}

	private static final char[] CSV_SEPARATORS = {',',';'};
	private static final int CSV_MAX_LEVEL = 1;

	private static final int INDENT_TOP_LEVEL_FACTOR = 0;
	private static final int INDENT_FACTOR = 2;

	private final XMLToCSVConverter xmlToCSV = new XMLToCSVConverter();

	private final String XML_CHARSET		="<?xml version=\"1.0\" encoding=\"utf-8\"?>";
	private final String XML_ROOTNAME		="root";
	private final String XML_DATA			="row";
	private final String TMP_XML_DATA		="tmp.xml";

	private static final SimpleDateFormat OUTPUT_DIRECTORY_FORMATER = new SimpleDateFormat("dd-MM-yyyy_HH-mm-ss-SSS");

	public final void wrapData(String inputFile, String outputFile) throws IOException
	{
		String fileContent = null;
		InputStream inputStream = null;
		String dateFormat = OUTPUT_DIRECTORY_FORMATER.format(new Date());
		System.out.println("dateFormat : "+dateFormat);

		// Load file input stream
		inputStream = Utils.getInputStreamFromFile(this, inputFile);
		System.out.println("inputStream : "+inputStream);

		// Load input stream content as String
		fileContent = IOUtils.toString(inputStream);		
		System.out.println("fileContent : "+fileContent);

		String sourceFormat = Utils.getFileExtension(inputFile);
		System.out.println("sourceFormat : "+sourceFormat);

		String destinationFormat = Utils.getFileExtension(outputFile);
		System.out.println("destinationFormat : "+destinationFormat);

		// Convert data format
		String outputFileContent = getConvertFile(inputFile, sourceFormat, destinationFormat);
		System.out.println("outputFileContent : "+outputFileContent);

		// Create files in output destination directory
		String destinationDirectory = DESTINATION_DIR + dateFormat + "." + Utils.getFileExtension(inputFile) + "-to-" + Utils.getFileExtension(outputFile) + "/" ;
		String destinationInputFilePath = destinationDirectory + Utils.getFileName(inputFile);
		String destinationOutputFilePath = destinationDirectory + outputFile;		

		String inputFilePath = createFile(destinationInputFilePath, fileContent);	
		System.out.println(inputFilePath+" succesfully saved !!!");		

		String outputFilePath = createFile(destinationOutputFilePath, outputFileContent);
		System.out.println(outputFilePath+" succesfully saved !!!");		
	}

	private final String getConvertFile(String filePath, String sourceFormat, String destinationFormat)
	{
		InputStream inputStream = Utils.getInputStreamFromFile(this, filePath);

		String file = null;
		String dataFileContent = null;

		if(DataType.BIN.equals(DataType.valueOf(destinationFormat.toUpperCase())) || DataType.BINARY.equals(DataType.valueOf(destinationFormat.toUpperCase())))
		{

			try {
				file = IOUtils.toString(inputStream);
			} catch (IOException e1) {
				e1.printStackTrace();
			}

			System.err.println("BIN - file : "+file);

			StringBuffer strBuffer = new StringBuffer();
			byte[] byteArray = file.getBytes();

			for (int i = 0; i < byteArray.length; i++)
			{
				String binary = Integer.toBinaryString(byteArray[i] & 0xFF);
				strBuffer.append(binary);
			}

			dataFileContent = strBuffer.toString();
		}
		else if(DataType.HEX.equals(DataType.valueOf(destinationFormat.toUpperCase())) || DataType.HEXADECIMAL.equals(DataType.valueOf(destinationFormat.toUpperCase())))
		{
			try {
				file = IOUtils.toString(inputStream);
			} catch (IOException e1) {
				e1.printStackTrace();
			}

			System.err.println("HEX - file : "+file);

			char[] chars = file.toCharArray();
			StringBuffer stringBuffer = new StringBuffer();

			for (int i = 0; i < chars.length; i++)
			{
				String hexadecimal = Integer.toHexString((int) chars[i]);
				stringBuffer.append(hexadecimal);
			}

			dataFileContent = stringBuffer.toString();
		}
		else{
			// Convert Data to XML DOM object
			Document xmlDOMObject = convertGivenDataToXMLDOMObject(inputStream, sourceFormat);
			System.out.println("xmlDOMObject : "+xmlDOMObject);

			// Create temporary file from XML DOM object
			DOMImplementationLS domImplementationLS = (DOMImplementationLS) xmlDOMObject.getImplementation();			
			LSOutput lsOutput =  domImplementationLS.createLSOutput();			
			lsOutput.setEncoding("UTF-8");
			lsOutput.setCharacterStream(new StringWriter());
			LSSerializer lsSerializer = domImplementationLS.createLSSerializer();
			lsSerializer.write(xmlDOMObject, lsOutput);

			// Format XML DOM string
			String xmlDOMObjectAsStringContent = formatDOMObject(xmlDOMObject);			
			System.out.println("xmlDOMObjectAsStringContent : "+xmlDOMObjectAsStringContent);

			// Create string from XML DOM object in resource directory
			String xmlTmpFilePath = this.getClass().getResource(SAMPLE_BASE_DIRECTORY).getPath() + TMP_XML_DATA;
			System.out.println("xmlTmpFilePath : "+xmlTmpFilePath);

			// Create temporary file from string XML DOM object content
			String xmlFilePath = createFile(xmlTmpFilePath, xmlDOMObjectAsStringContent);			
			System.out.println("xmlFilePath : "+xmlFilePath);

			dataFileContent = convertDOMObjectToGivenData(xmlDOMObject, destinationFormat, inputStream, SAMPLE_BASE_DIRECTORY + TMP_XML_DATA);			
		}
		System.out.println("dataFileContent : "+dataFileContent);
		return dataFileContent;
	}

	/**
	 * Creates a new XML object (DOM) object from input stream and data type.
	 * @param {@link String} filePath 
	 * @param type data type
	 * @return {@link Document} xml object
	 */
	private final Document convertGivenDataToXMLDOMObject(InputStream fileInputStream, String inputFormatType) throws IllegalFormatException
	{
		Document documentXML = null;
		InputSource inputSource = null;
		StringReader stringReader = null;
		Reader reader = null;
		String outputXMLString = null;

		try {

			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder documentBuilder = factory.newDocumentBuilder();

			switch( DataType.valueOf( inputFormatType.toUpperCase() ) )
			{

			case JSON:
				String jsonData = IOUtils.toString(fileInputStream);
				XMLSerializer serializer = new XMLSerializer();       
				JSON json = JSONSerializer.toJSON(jsonData);
				String jsonToXML = serializer.write(json);
				stringReader = new StringReader(jsonToXML);
				inputSource = new InputSource(stringReader);
				documentXML = documentBuilder.parse(inputSource);
				break;

			case CSV:
				reader = new InputStreamReader(fileInputStream);
				char detectedSeparator = ',' /*detectCSVSeparator(new StringReader(""), CSV_SEPARATOR)*/;
				System.out.println("CSV - detectedSeparator : "+detectedSeparator);
				CSVReader csvReader = new CSVReader(reader, detectedSeparator);
				String[] lines = null;        
				String[] headers = csvReader.readNext();				
				System.out.println("CSV - headers :  "+headers);
				StringBuilder str = new StringBuilder();
				str.append(XML_CHARSET);
				str.append("<"+XML_ROOTNAME+">");
				while((lines  = csvReader.readNext()) != null )
				{
					str.append("<"+XML_DATA+">");
					for (int i = 0; i < headers.length; i++) 
					{
						str.append("<"+headers[i].replaceAll("\\s", "")+">");
						str.append(lines[i]);
						str.append("</"+headers[i].replaceAll("\\s", "")+">");
					}
					str.append("</"+XML_DATA+">");
				}
				str.append("</"+XML_ROOTNAME+">");

				outputXMLString = str.toString();
				csvReader.close();

				System.out.println("CSV - outputXMLString =  "+outputXMLString);

				stringReader = new StringReader(outputXMLString);
				inputSource = new InputSource(stringReader);
				documentXML = documentBuilder.parse(inputSource);
				break;

			case YML:
			case YAML:
				reader = new InputStreamReader(fileInputStream);

				try {	
					YamlReader yamlBeansReader = new YamlReader(reader);
					StringBuilder stringBuilder = new StringBuilder();			
					stringBuilder.append(XML_CHARSET.toString());
					stringBuilder.append("<"+XML_ROOTNAME+">");
					String nodeAsString = null;
					Object objectData 	= null;	

					while (true)
					{
						objectData = yamlBeansReader.read();
						if (objectData == null) {
							break;
						}
						else{
							nodeAsString = collectionToXmlString(objectData, new StringBuilder());
							stringBuilder.append(nodeAsString);
						}
					}

					stringBuilder.append("</"+XML_ROOTNAME+">");

					outputXMLString = stringBuilder.toString().trim();
					System.out.println("outputXMLString : " +outputXMLString);					
					documentXML = convertXMLStringToDOMObject(outputXMLString);
				}
				catch (YamlException e) {
					e.printStackTrace();
				}
				reader.close();
				break;

			case SQL:
				String sqlQueryContent = IOUtils.toString(fileInputStream);
				documentXML = convertResultSetToDOMObject(sqlQueryContent);
				break;

			case XML:
				documentXML = documentBuilder.parse(fileInputStream);
				
				DOMSource domSource = new DOMSource(documentXML);
				Transformer xmlTransformer = TransformerFactory.newInstance().newTransformer();
				xmlTransformer.setParameter(OutputKeys.INDENT, "yes");
				xmlTransformer.setParameter("{http://xml.apache.org/xslt}indent-amount", "2");
				xmlTransformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
				xmlTransformer.setOutputProperty(OutputKeys.METHOD, "xml");
				xmlTransformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
				xmlTransformer.setOutputProperty(OutputKeys.INDENT, "yes");
				xmlTransformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
				StringWriter sw = new StringWriter();
				StreamResult sr = new StreamResult(sw);
				xmlTransformer.transform(domSource, sr);
				String transformedString = sw.toString();
				System.out.println(transformedString.toUpperCase());
				stringReader = new StringReader(transformedString);					
				inputSource = new InputSource(stringReader);
				documentXML = documentBuilder.parse(inputSource);
				
				/*
				formatDOMObject(documentXML);
				try {
					formatXMLFile(filePath, xmlObject);
				} catch (Exception e) {
					e.printStackTrace();
				}
				*/
			default:
				break;
			}
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		} catch (SAXException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (TransformerConfigurationException e) {
			e.printStackTrace();
		} catch (TransformerFactoryConfigurationError e) {
			e.printStackTrace();
		} catch (TransformerException e) {
			e.printStackTrace();
		}

		return documentXML;		
	}

	private int detectXMLMaxDepth(NodeList nodeList, int level)
	{
		level++;

		if(nodeList != null && nodeList.getLength() > 0)
		{
			for (int i = 0; i < nodeList.getLength(); i++)
			{
				Node node = nodeList.item(i);
				int tmp = detectXMLMaxDepth(node.getChildNodes(), level);
				tmp = Math.max(0, tmp);
			}

		}	

		return level;
	}

	/**
	 * Converts an XML object (DOM) to data type represent as String
	 * @param {@link Document} xml object
	 * @param outputType data type
	 * @return {@link String} outputString 
	 */
	private final String convertDOMObjectToGivenData(Document xmlObject, String outputFormatType, InputStream inputStream, String filePath)
	{		
		String outputDataString = null;

		switch(DataType.valueOf(outputFormatType.toUpperCase()))
		{
		case JSON:
			String toJSON = formatDOMObject(xmlObject);
			JSON json = new XMLSerializer().read(toJSON);
			String xmlToJSON = json.toString(INDENT_FACTOR, INDENT_TOP_LEVEL_FACTOR);
			outputDataString = xmlToJSON;
			break;

		case CSV:
			Element elem = xmlObject.getDocumentElement();
			NodeList nodelist = elem.getChildNodes();
			//displayLevel(nodelist, 1);
			int maxDepth = detectXMLMaxDepth(nodelist, CSV_MAX_LEVEL);
			//TODO: detect depth, if more than 1 level throw exception
			//IllegalFormatException();ParseExceptionDataFormatException;
			if(maxDepth > CSV_MAX_LEVEL)
			{
				throw new UnknownFormatConversionException("Format not supported, XML file too deep : "+maxDepth);
			}
			try {
				outputDataString = xmlToCSV.convert(xmlObject);
			} catch (Exception e){
				e.printStackTrace();
			}
			break;

		case YML:
		case YAML:
			System.out.println("inputStream - 1 : "+inputStream);
			OutputStream outputStream = new ByteArrayOutputStream();
			System.out.println("inputStream : "+inputStream);
			System.out.println("xmlObject : "+xmlObject);				
			transformYamltoXMLfromXSL(xmlObject, inputStream, outputStream, filePath);
			outputDataString = outputStream.toString();
			break;

		case SQL:
			Connection conn = null;
			Reader reader = null;
			try {
				//Class.forName("org.hsqldb.jdbcDriver");
				//conn = DriverManager.getConnection("jdbc:hsqldb:mem:sptest", "sa", "");
				System.out.println("filePath " + filePath);
				reader = Resources.getResourceAsReader(filePath);				
				ScriptRunner runner = new ScriptRunner(conn);
				runner.setDelimiter("]");
				runner.setLogWriter(null);
				runner.setErrorLogWriter(null);
				runner.runScript(reader);
				//conn.commit();
				//conn.close();
				System.out.println("reader " + reader);
				reader.close();
				/*} catch (ClassNotFoundException e) {
					e.printStackTrace();
				} catch (SQLException e) {
					e.printStackTrace();*/					
			} catch (IOException e) {
				e.printStackTrace();					
			} 
			break;

		case XML:
			outputDataString = formatDOMObject(xmlObject);
		default:
			break;
		}
		System.out.println("outputDataString : "+outputDataString);
		return outputDataString;		
	}

	private final String formatDOMObject(Document xmlDOMObject)
	{
		DOMImplementationLS domImplementationLS = (DOMImplementationLS) xmlDOMObject.getImplementation();			
		LSOutput lsOutput =  domImplementationLS.createLSOutput();			
		lsOutput.setEncoding("UTF-8");			
		Writer stringWriter = new StringWriter();
		lsOutput.setCharacterStream(stringWriter);
		LSSerializer lsSerializer = domImplementationLS.createLSSerializer();
		lsSerializer.write(xmlDOMObject, lsOutput);
		return stringWriter.toString();
	}

	private static void formatXMLFile(String file, Document document) throws Exception
	{
		Transformer xformer = TransformerFactory.newInstance().newTransformer();
		xformer.setOutputProperty(OutputKeys.METHOD, "xml");
		xformer.setOutputProperty(OutputKeys.INDENT, "yes");
		xformer.setOutputProperty("b;http://xml.apache.org/xsltd;indent-amount", "4");
		xformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
		Source source = new DOMSource(document);
		Result result = new StreamResult(new File(file));
		xformer.transform(source, result);
	}


	private char detectCSVSeparator(Reader reader, char[] separartors)
	{
		char separartorDetected = separartors[0];
		BufferedReader bufferReader = new BufferedReader(reader);
		try {
			String line = bufferReader.readLine();
			System.err.println("line : " + line);
			for (int i = 0; i < separartors.length; i++)
			{
				String[] separated = line.split(String.valueOf(separartors[i]));
				if(separated.length > 1 )
				{
					System.err.println("separartor : " + String.valueOf(separartors[i]));
					System.err.println("separated.length : " + separated.length);
					separartorDetected = separartors[i];
					break;
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

		return separartorDetected;		
	}

	/**
	 * Create a file with the specified data content.
	 * @param fileContent data as String
	 * @param extension (SQL, XML, etc)
	 * @return
	 */
	private final String createFile(String destinationFilePath, String fileContent)
	{
		File file = null;
		try {
			file = new File(destinationFilePath);
			FileUtils.writeStringToFile(file, fileContent);
		}
		catch (IOException e) {
			e.printStackTrace();
		}
		return file.getAbsolutePath();		
	}

	public static void doSomething(Node node, ArrayList goodChildren) {
		// do something with the current node instead of System.out
		System.out.println(node.getNodeName());

		NodeList nodeList = node.getChildNodes();
		for (int i = 0; i < nodeList.getLength(); i++) {
			Node currentNode = nodeList.item(i);
			if (currentNode.getNodeType() == Node.ELEMENT_NODE) {
				//calls this method for all the children which is Element
				System.out.println(currentNode);
				doSomething(currentNode, goodChildren);
			}else{
				System.err.println(currentNode);
			}
		}
	}

	private Document convertResultSetToDOMObject(String sqlQuery)
	{
		System.out.println("SQL query : "+sqlQuery);
		Document document = null;
		String databaseFileName = Utils.getResourceFilePath(this, "/sample/data/dbsql2xml/pays.db");

		try {
			document = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
			Element results = document.createElement(XML_ROOTNAME);
			document.appendChild(results);

			//Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
			//Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/tapsm","root", "");		   
			Class.forName("org.sqlite.JDBC");
			Connection connection= DriverManager.getConnection("jdbc:sqlite:"+databaseFileName);			
			Statement statement = connection.createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);
			ResultSet resultSet = statement.executeQuery(sqlQuery);
			ResultSetMetaData rsmd = resultSet.getMetaData();
			int colCount = rsmd.getColumnCount();

			while (resultSet.next())
			{
				Element row = document.createElement(XML_DATA);
				results.appendChild(row);
				for (int i = 1; i <= colCount; i++)
				{
					String columnName = rsmd.getColumnName(i);
					Object value = resultSet.getObject(i);
					Element node = document.createElement(columnName);
					node.appendChild(document.createTextNode(value.toString()));
					row.appendChild(node);
				}
			}

			DOMSource domSource = new DOMSource(document);
			TransformerFactory tf = TransformerFactory.newInstance();
			Transformer transformer = tf.newTransformer();
			transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
			transformer.setOutputProperty(OutputKeys.METHOD, "xml");
			transformer.setOutputProperty(OutputKeys.ENCODING, "ISO-8859-1");
			StringWriter sw = new StringWriter();
			StreamResult sr = new StreamResult(sw);
			transformer.transform(domSource, sr);

			resultSet.close();
			connection.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

		return document;		
	}

	private Document convertXMLStringToDOMObject(String xmlString)
	{
		Document document = null;
		try {
			DocumentBuilder documentBuilder;
			documentBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
			if (LOGGER.isEnabledFor(Priority.INFO)) LOGGER.info(xmlString);
			StringReader stringReader = new StringReader(xmlString);
			InputSource inputSource = new InputSource(stringReader);
			document = documentBuilder.parse(inputSource);
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		} catch (SAXException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		if (LOGGER.isEnabledFor(Priority.INFO)) LOGGER.info(document);
		return document;
	}

	/**
	 *  TODO : Use subtype polymorphism scenario
	 *  
	 *  Example :
	 *  <pre>
	 *  interface I {
	 * 		void do();
	 *	}
	 *	</pre>
	 *
	 *	<pre>class A implements I { void do() { doA() } ... }</pre>
	 *	<br /><pre>class B implements I { void do() { doB() } ... }</pre>
	 *	<br /><pre>class C implements I { void do() { doC() } ... }</pre>
	 */
	private final String collectionToXmlString(Object objectCollection, StringBuilder stringBuilder)
	{
		if(objectCollection.getClass() == HashMap.class)
		{
			if (LOGGER.isTraceEnabled()) LOGGER.debug("[HashMap] : "+objectCollection);
			Map map = (Map) objectCollection;
			Iterator it = map.entrySet().iterator();
			while (it.hasNext()) 
			{
				Map.Entry pairs = (Map.Entry) it.next();
				// Handle whitespace in key
				String formatedKey = String.valueOf(pairs.getKey()).replaceAll("\\s+","");
				if (LOGGER.isInfoEnabled()) LOGGER.debug("<" +formatedKey+ ">");
				stringBuilder.append("<" +formatedKey+ ">");
				collectionToXmlString(pairs.getValue(), stringBuilder);
				it.remove(); // avoids a ConcurrentModificationException
				if (LOGGER.isInfoEnabled()) LOGGER.debug("</" +formatedKey+ ">");
				stringBuilder.append("</" +formatedKey+ ">");
			}		
		}
		else if(objectCollection.getClass() == ArrayList.class){
			if (LOGGER.isTraceEnabled()) LOGGER.debug("[ArrayList] : "+objectCollection);
			ArrayList array = (ArrayList) objectCollection;

			for (int i = 0; i < array.size(); i++) 
			{
				collectionToXmlString(array.get(i), stringBuilder);
			}

		}
		else if(objectCollection.getClass() == LinkedList.class){			
			if (LOGGER.isTraceEnabled()) LOGGER.debug("[LinkedList] : "+objectCollection);

		}
		else if(objectCollection.getClass() == String.class){

			if (LOGGER.isTraceEnabled()) LOGGER.debug("[String] : "+objectCollection);
			if (LOGGER.isInfoEnabled()) LOGGER.debug(objectCollection);
			stringBuilder.append(objectCollection);
		}

		return stringBuilder.toString();

	}

	private final String mapToXmlString(Map map) {
		Iterator it = map.entrySet().iterator();
		StringBuilder str = new StringBuilder();
		str.append(XML_CHARSET);
		System.out.println(XML_CHARSET);
		str.append("<"+XML_ROOTNAME+">");
		System.out.println("<"+XML_ROOTNAME+">");

		while (it.hasNext())
		{
			Map.Entry pairs = (Map.Entry) it.next();
			//parseNode(pairs.getKey(), pairs.getValue(), str);
			parseNodes(pairs.getKey(), pairs.getValue(), str);
			it.remove(); // avoids a ConcurrentModificationException
		}

		str.append("</"+XML_ROOTNAME+">");
		System.out.println("</"+XML_ROOTNAME+">");
		return str.toString();		
	}

	private void transformYamltoXMLfromXSL(Document document, InputStream inputStream, OutputStream outputStream, String filePath)
	{

		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setNamespaceAware(true);
		factory.setValidating(true);

		try {

			DocumentBuilder documentBuilder = factory.newDocumentBuilder();
			System.out.println("filePath : "+filePath);

			URL datafileURL = this.getClass().getResource(filePath);			
			System.out.println("datafileURL - 1 : "+datafileURL);

			File datafile =  new File(datafileURL.getPath());
			System.out.println("datafile - 1 : "+datafile);

			document = documentBuilder.parse(datafile);
			System.out.println("file document : "+document);

			// Use a Transformer for output
			TransformerFactory transformerFactory = TransformerFactory.newInstance();			
			URL stylesheetURL = this.getClass().getResource(SAMPLE_BASE_DIRECTORY + "xml2yaml.xsl");
			File stylesheet = new File(stylesheetURL.getPath());
			System.out.println("stylesheet : "+stylesheet);			
			StreamSource stylesource = new StreamSource(stylesheet);
			Transformer transformer = transformerFactory.newTransformer(stylesource);

			DOMSource source = new DOMSource(document);
			StreamResult result = new StreamResult(outputStream);
			transformer.transform(source, result);
		}
		catch (TransformerConfigurationException tce) {
			// Error generated by the parser
			System.out.println("\n** Transformer Factory error");
			System.out.println("   " + tce.getMessage());

			// Use the contained exception, if any
			Throwable x = tce;

			if (tce.getException() != null) {
				x = tce.getException();
			}

			x.printStackTrace();
		}
		catch (TransformerException te) {
			// Error generated by the parser
			System.out.println("\n** Transformation error");
			System.out.println("   " + te.getMessage());

			// Use the contained exception, if any
			Throwable x = te;

			if (te.getException() != null) {
				x = te.getException();
			}

			x.printStackTrace();
		}
		catch (SAXException sxe) {
			// Error generated by this application
			// (or a parser-initialization error)
			Exception x = sxe;

			if (sxe.getException() != null) {
				x = sxe.getException();
			}

			x.printStackTrace();
		}
		catch (ParserConfigurationException pce) {
			// Parser with specified options can't be built
			pce.printStackTrace();
		}
		catch (IOException ioe) {
			// I/O error
			ioe.printStackTrace();
		}
	}

	public static Map<String, String> convertNodesFromXml(String xml) throws Exception
	{
		InputStream is = new ByteArrayInputStream(xml.getBytes());
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		dbf.setNamespaceAware(true);
		DocumentBuilder db = dbf.newDocumentBuilder();
		Document document = db.parse(is);
		return createMap(document.getDocumentElement());
	}

	public static Map createMap(Node node)
	{
		Map<String, Object> map = new LinkedHashMap<String, Object>();
		NodeList nodeList = node.getChildNodes();

		for (int i = 0; i < nodeList.getLength(); i++) {
			Node currentNode = nodeList.item(i);
			if (currentNode.hasAttributes()) {
				for (int j = 0; j < currentNode.getAttributes().getLength(); j++) {
					Node item = currentNode.getAttributes().item(i);
					map.put(item.getNodeName(), item.getTextContent());
				}
			}
			if (node.getFirstChild() != null && node.getFirstChild().getNodeType() == Node.ELEMENT_NODE) {
				map.putAll(createMap(currentNode));
			} else if (node.getFirstChild().getNodeType() == Node.TEXT_NODE) {
				map.put(node.getLocalName(), node.getTextContent());
			}
		}

		return map;
	}

	private static void printNode(NodeList nodeList)
	{

		for (int count = 0; count < nodeList.getLength(); count++) {

			Node tempNode = nodeList.item(count);

			// make sure it's element node.
			if (tempNode.getNodeType() == Node.ELEMENT_NODE) {

				// get node name and value
				System.out.println("\nNode Name =" + tempNode.getNodeName() + " [OPEN]");
				System.out.println("Node Value =" + tempNode.getTextContent());

				if (tempNode.hasAttributes()) {

					// get attributes names and values
					NamedNodeMap nodeMap = tempNode.getAttributes();

					for (int i = 0; i < nodeMap.getLength(); i++) {
						Node node = nodeMap.item(i);
						System.out.println("attr name : " + node.getNodeName());
						System.out.println("attr value : " + node.getNodeValue());
					}

				}

				if (tempNode.hasChildNodes()) {
					// loop again if has child nodes
					printNode(tempNode.getChildNodes());

				}

				System.out.println("Node Name =" + tempNode.getNodeName() + " [CLOSE]");

			}

		}

	}

	private void parseNode(Object key, Object value, StringBuilder str) {

		if(value instanceof HashMap)
		{
			System.out.println("<" +key+ ">");
			str.append("<" +key+ ">");
			Map map = (Map) value;
			Iterator it = map.entrySet().iterator();
			while (it.hasNext()) {
				Map.Entry pairs = (Map.Entry) it.next();
				parseNode(pairs.getKey(), pairs.getValue(), str);
				it.remove(); // avoids a ConcurrentModificationException
			}
			str.append("<" +key+ ">");
			System.out.println("</" +key+ ">");
		}
		else if(value instanceof ArrayList)
		{
			str.append("<" +key+ ">");
			System.out.println("<" +key+ ">");
			ArrayList array = (ArrayList) value;

			for (int i = 0; i < array.size(); i++) 
			{
				Map map = (Map) array.get(i);
				Iterator it = map.entrySet().iterator();

				while (it.hasNext()) 
				{
					Map.Entry pairs = (Map.Entry) it.next();
					parseNode(pairs.getKey(), pairs.getValue(), str);
					it.remove(); // avoids a ConcurrentModificationException
				}
			}

			str.append("</" +key+ ">");
			System.out.println("</" +key+ ">");
		}
		else{
			str.append("<" +key+ ">"+value+"</" +key+ ">");
			System.out.println("<" +key+ ">"+value+"</" +key+ ">");
		}

	}

	private void parseNodes(Object key, Object value, StringBuilder str)
	{
		if(value instanceof HashMap)
		{
			System.out.println("<" +key+ ">");
			str.append("<" +key+ ">");

			Map map = (Map) value;
			Iterator it = map.entrySet().iterator();

			while (it.hasNext())
			{
				Map.Entry pairs = (Map.Entry) it.next();
				parseNode(pairs.getKey(), pairs.getValue(), str);
				it.remove();
			}

			str.append("<" +key+ ">");
			System.out.println("</" +key+ ">");
		}
		else if(value instanceof ArrayList)
		{
			str.append("<" +key+ ">");
			System.out.println("<" +key+ ">");
			ArrayList array = (ArrayList) value;

			for (int i = 0; i < array.size(); i++) 
			{
				if(array.get(i) instanceof HashMap)
				{

					Map map = (Map) array.get(i);
					Iterator it = map.entrySet().iterator();

					while (it.hasNext()) 
					{
						Map.Entry pairs = (Map.Entry) it.next();
						parseNode(pairs.getKey(), pairs.getValue(), str);
						it.remove();
					}

				}else if(array.get(i) instanceof String){
					str.append("<" +key+ ">"+value+"</" +key+ ">");
					System.out.println("<" +key+ ">"+value+"</" +key+ ">");
				}

			}

			str.append("</" +key+ ">");
			System.out.println("</" +key+ ">");
		}
		else{
			str.append("<" +key+ ">"+value+"</" +key+ ">");
			System.out.println("<" +key+ ">"+value+"</" +key+ ">");
		}

	}

	private final class XMLToCSVConverter
	{
		// Default private/protected ?
		private String source;
		private String result;
		private String emptyValue = "-";
		private String separator = ",";
		private String loopFieldName;
		private boolean distinct;
		private HashSet<String> keepOnlyFieldsNames = new HashSet<String>();
		private HashSet<String> ignoreFieldsNames = new HashSet<String>();
		private Map<String, String> fields = new TreeMap<String, String>();
		private Map<String, String> values = new TreeMap<String, String>();
		private Set<Integer> previousValues = new HashSet<Integer>();
		private Map<String, Integer> levels = new TreeMap<String, Integer>();
		private Map<String, String> loopFields = new TreeMap<String, String>();
		private Map<String, Integer> loops = new TreeMap<String, Integer>();
		private boolean gotFirstElement;

		/**
		 * Constructor
		 * @param source
		 */
		@SuppressWarnings("unused")
		public XMLToCSVConverter(String source) {
			this(source, null, null, null, false);
		}

		/**
		 * Constructor
		 * @param source the filename our URL to XML schema
		 * @param loopFieldName the name of the field that repeats in XML schema
		 */
		public XMLToCSVConverter(String source, String loopFieldName) {
			this(source, loopFieldName, null, null, false);
		}

		/**
		 * Constructor
		 * @param source the filename our url ot XML schema
		 * @param loopFieldName the name of the field that repeats in XML schema
		 * @param keepOnlyFieldsNames the names of the fields that will be kept
		 * @param ignoreFieldsNames the names of the fields that will be ignored
		 * @param distinct - if true, returns not duplicated rows
		 */
		public XMLToCSVConverter(String source, String loopFieldName,
				HashSet<String> keepOnlyFieldsNames,
				HashSet<String> ignoreFieldsNames, boolean distinct) {
			this(source, loopFieldName, keepOnlyFieldsNames, ignoreFieldsNames,
					distinct, null, null);
		}

		/**
		 * Constructor
		 * @param source the filename our url ot XML schema
		 * @param distinct - if true, returns not duplicated rows
		 * @param emptyValue the value for empty data
		 * @param separator the value for separator in CSV
		 */
		public XMLToCSVConverter(String source, boolean distinct, String emptyValue,
				String separator) {
			this(source, null, null, null, distinct, emptyValue, separator);
		}

		/**
		 * Constructor
		 * @param source the filename our url ot XML schema
		 * @param loopFieldName the name of the field that repeats in XML schema
		 * @param keepOnlyFieldsNames the names of the fields that will be kept
		 * @param ignoreFieldsNames the names of the fields that will be ignored
		 * @param distinct - if true, returns not duplicated rows
		 * @param emptyValue the value for empty data
		 * @param separator the value for separator in CSV
		 */
		public XMLToCSVConverter(String source, String loopFieldName,
				HashSet<String> keepOnlyFieldsNames,
				HashSet<String> ignoreFieldsNames, boolean distinct,
				String emptyValue, String separator) {
			this.source = source;
			this.loopFieldName = loopFieldName;
			if (keepOnlyFieldsNames != null) {
				this.keepOnlyFieldsNames.addAll(keepOnlyFieldsNames);
			}
			if (ignoreFieldsNames != null) {
				this.ignoreFieldsNames.addAll(ignoreFieldsNames);
			}
			this.distinct = distinct;
			if (emptyValue != null) {
				this.emptyValue = emptyValue;
			}
			if (separator != null) {
				this.separator = separator;
			}
		}

		public XMLToCSVConverter() {
			this(null, null, null, null, false);
		}

		/**
		 * Converts XML data to CSV data
		 * @return converted data
		 * @throws ParserConfigurationException
		 * @throws SAXException
		 * @throws IOException
		 */
		@SuppressWarnings("unused")
		public String convert() throws ParserConfigurationException, 
		SAXException, IOException {
			this.fields.clear();
			this.levels.clear();
			this.values.clear();
			previousValues.clear();
			this.gotFirstElement = false;
			this.result = "";
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();
			Document root = builder.parse(this.source);
			this.parseFields((Node) root, 0);

			if (this.loopFieldName == null){
				this.determineLoopFieldName();
			}

			this.parseValues((Node) root, 0);
			return this.result;
		}

		public String convert(Document root) 
		{
			this.parseFields((Node) root, 0);

			if (this.loopFieldName == null) {
				this.determineLoopFieldName();
			}

			this.parseValues((Node) root, 0);
			return this.result;
		}

		/**
		 * Parse nodes to the fields, recursive function
		 * @param node
		 * @param level
		 */
		private void parseFields(Node node, int level) {
			this.addToLoopFields(level,node.getNodeName());
			if (node.hasAttributes()) {
				NamedNodeMap attributes = node.getAttributes();
				for (int i = 0; i < attributes.getLength(); i++)
				{
					Node attribute = attributes.item(i);
					this.addToFields(level, node.getNodeName(), attribute.getNodeName());
				}
			}

			boolean hastext = false;
			boolean haselement = false;
			NodeList children = node.getChildNodes();

			for (int i = 0; i < children.getLength(); i++)
			{
				Node child = children.item(i);
				if (child instanceof Element) {
					haselement = true;
					this.parseFields(child, level+1);
				}
				else if (child.getNodeName().equals("#text") && 
						!child.getNodeValue().trim().isEmpty()) {
					hastext = true;
				}
			}

			if (!haselement && hastext) {
				this.addToFields(level, node.getNodeName());
			}
		}

		/**
		 * Parse nodes to the values, writes data to result, recursive function
		 * @param node
		 * @param level
		 */
		private void parseValues(Node node, int level)
		{

			if (node.getNodeName().equals(this.loopFieldName)) {
				if (this.gotFirstElement) {
					this.printMapToResult(values);
					this.resetValuesInRow(level);
				} else {
					this.printMapToResult(fields);
					this.gotFirstElement = true;
				}
			}

			if (node.hasAttributes()) {
				NamedNodeMap attributes = node.getAttributes();
				for (int i = 0; i < attributes.getLength(); i++)
				{
					Node attribute = attributes.item(i);
					this.addToValues(attribute.getNodeValue(), level, node.getNodeName(),
							attribute.getNodeName());
				}
			}

			boolean hastext = false;
			boolean haselement = false;
			NodeList children = node.getChildNodes();

			for (int i = 0; i < children.getLength(); i++)
			{
				Node child = children.item(i);
				if (child instanceof Element)
				{
					haselement = true;
					this.parseValues(child, level+1);
				}
				else if (child.getNodeName().equals("#text") &&
						!child.getNodeValue().trim().isEmpty()) {
					hastext = true;
				}
			}

			if (!haselement && hastext)
			{
				this.addToValues(node.getFirstChild().getNodeValue(), level, node.getNodeName());
			}
		}

		/**
		 * Determine loopFieldName
		 */
		private void determineLoopFieldName()
		{
			int max = 0;
			String maxField = null;
			for (String key : this.loopFields.keySet()) {
				if (this.loops.get(key) > max) {
					max = this.loops.get(key);
					maxField = this.loopFields.get(key);
				}
				if (max >= 2) break;
			}
			this.loopFieldName = maxField;
		}

		/**
		 * Add node to the fields' Tree Maps
		 * @param level
		 * @param nodeName
		 */
		private void addToFields(int level, String nodeName)
		{
			this.addToFields(level, nodeName, "");
		}

		/**
		 * Add node to the fields' Tree Maps
		 * @param level
		 * @param nodeName
		 * @param argName
		 */
		private void addToFields(int level, String nodeName, String argName)
		{
			if (!this.keepOnlyFieldsNames.isEmpty())
			{
				if (!this.keepOnlyFieldsNames.contains(nodeName)){
					return;
				}
			} else {
				if (this.ignoreFieldsNames.contains(nodeName)) {
					return;
				}
			}

			String key = this.makeKey(level, nodeName, argName);
			String name = this.makeKey(null, nodeName, argName);
			this.fields.put(key, name);
			this.values.put(key, this.emptyValue);
			this.levels.put(key, level);
		}

		/**
		 * Helper function to determine loopFieldName
		 * @param level
		 * @param nodeName
		 */
		private void addToLoopFields(int level, String nodeName) {
			String key = this.makeKey(level, nodeName, null);
			String name = this.makeKey(null, nodeName, null);
			this.loopFields.put(key, name);
			Integer loop = this.loops.get(key);
			if (loop == null) loop = 0;
			this.loops.put(key, loop+1);
		}

		/**
		 * Add node to the values' Tree Maps
		 * @param value
		 * @param level
		 * @param nodeName
		 */
		private void addToValues(String value, int level, String nodeName) {
			this.addToValues(value, level, nodeName, null);
		}

		/**
		 * Add node to the values' Tree Maps
		 * @param value
		 * @param level
		 * @param nodeName
		 * @param argName
		 */
		private void addToValues(String value, int level, String nodeName, String argName) {
			String key = this.makeKey(level, nodeName, argName);
			if (this.fields.containsKey(key)) {
				this.values.put(key, value);
			}
		}

		/**
		 * Generate key to the Tree Maps
		 * @param level
		 * @param nodeName
		 * @param argName
		 * @return generated key
		 */
		private String makeKey(Integer level, String nodeName, String argName) {

			String ret = "";

			if (level != null) {
				ret += level + ":";
			}

			ret += nodeName;

			if (argName != null && !argName.isEmpty()){
				ret += " [" + argName + "]";
			}
			return ret;
		}

		/**
		 * Reset values in the row for fields, which level is greater/equeal
		 * then/to argument
		 * @param level
		 */
		private void resetValuesInRow (int level) {
			for (String i : this.levels.keySet()) {
				if (this.levels.get(i) >= level) {
					this.values.put(i, this.emptyValue);
				}
			}
		}

		/**
		 * Print row data to result
		 * @param map
		 */
		private void printMapToResult (Map<String, String> map) {
			if (this.distinct) {
				if (previousValues.contains(map.hashCode())) {
					return;
				}
				previousValues.add(map.hashCode());
			}
			Iterator<String> iter =  map.values().iterator();
			while (iter.hasNext()) {
				result += iter.next().replace(this.separator, " ");
				if (iter.hasNext()) {
					result += this.separator;
				}
			}
			result += System.getProperty("line.separator");
		}

	}

}