package client;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import main.Utils;

import org.apache.commons.io.IOUtils;

public class SQLiteHelper {

	public static void main(String args[])
	{
		Connection connection = null;
		Statement statement = null;
		
		String SQL_FILE_PATH = "/sample/data/dbsql2xml/pays.sql";
		
		try {
			Class.forName("org.sqlite.JDBC");
			connection = DriverManager.getConnection("jdbc:sqlite:pays.db");
			System.out.println("Opened database successfully");
			statement = connection.createStatement();
			SQLiteHelper sqliteHelper = new SQLiteHelper();
			InputStream inputStream = Utils.getInputStreamFromFile(sqliteHelper, SQL_FILE_PATH);
			String sql = IOUtils.toString(inputStream);	
			statement.executeUpdate(sql);
			statement.close();
			connection.close();
		}
		catch ( Exception e ) {
			System.err.println( e.getClass().getName() + ": " + e.getMessage() );
			System.exit(0);
		}
		System.out.println("Table created successfully");
	}

}
