package client;

/*
examples how to use "dbsql2xml"
these mapping XML files works without modification only on certain configuration of HSQLDB 1.8.0
otherwise You need to modify them
 */
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.*;

import main.CrossDataWrapper;
import main.DatabaseSQL2XML;
import main.Utils;

import org.w3c.dom.*;

public class ExampleOfUse
{

	private static final String SAMPLE_TEST_DIR = "/sample/data/dbsql2xml/";

	public static void main(String[] args) {
		Date date;
		Date oldDate;


		/**
    standard output should be used for debugging
    File should beused for standalone conversion tool 
    String and Document should be used for server side component
      such as servlet or application server
		 */
		try {
			CrossDataWrapper crossDataWrapper = new CrossDataWrapper();

			// FLAT XML
			//do export into standard output
			System.out.println("flat into standard output: ");
			oldDate = new Date();
			String xmlFilePath = Utils.getResourceFilePath(crossDataWrapper, SAMPLE_TEST_DIR + "flatXMLMapping.xml");
			System.out.println("xmlFilePath : "+xmlFilePath);
			String xsdFilePath = Utils.getResourceFilePath(crossDataWrapper, SAMPLE_TEST_DIR + "dbsql2xml.xsd");
			System.out.println("xsdFilePath : "+xsdFilePath);
			DatabaseSQL2XML test01 = new DatabaseSQL2XML(xmlFilePath, xsdFilePath, "", "");
			test01.doExportIntoStandardOutput();
			date = new Date();
			System.out.println("date : "+(date.getTime() - oldDate.getTime()));
/*
			//do export into File
			System.out.println("flat into File: ");
			oldDate = new Date();
			DatabaseSQL2XML test02 = new DatabaseSQL2XML("flatXMLMapping.xml", "dbsql2xml.xsd", "", "", "flatXMLOut.xml");
			test02.doExportIntoFile();
			date = new Date();
			System.out.println(date.getTime() - oldDate.getTime());

			//do export into String
			System.out.println("flat into String: ");
			oldDate = new Date();
			DatabaseSQL2XML test03 = new DatabaseSQL2XML("flatXMLMapping.xml", "dbsql2xml.xsd", "", "");
			String outputString03 = test03.doExportIntoString();
			date = new Date();
			System.out.println(date.getTime() - oldDate.getTime());

			//do export into XML Document
			System.out.println("flat into XML Document: ");
			oldDate = new Date();
			DatabaseSQL2XML test04 = new DatabaseSQL2XML("flatXMLMapping.xml", "dbsql2xml.xsd", "", "");
			Document outDocument04 = test04.doExportIntoDocument();
			date = new Date();
			System.out.println(date.getTime() - oldDate.getTime());

			// TREE XML
			//do export into standard output
			System.out.println("tree into standard output: ");
			oldDate = new Date();
			DatabaseSQL2XML test05 = new DatabaseSQL2XML("treeXMLMapping.xml", "dbsql2xml.xsd", "", "");
			test05.doExportIntoStandardOutput();
			date = new Date();
			System.out.println(date.getTime() - oldDate.getTime());

			//do export into File
			System.out.println("tree into File: ");
			oldDate = new Date();
			DatabaseSQL2XML test06 = new DatabaseSQL2XML("treeXMLMapping.xml", "dbsql2xml.xsd", "", "", "treeXMLOut.xml");
			test06.doExportIntoFile();
			date = new Date();
			System.out.println(date.getTime() - oldDate.getTime());

			//do export into String
			System.out.println("tree into String: ");
			oldDate = new Date();
			DatabaseSQL2XML test07 = new DatabaseSQL2XML("treeXMLMapping.xml", "dbsql2xml.xsd", "", "");
			String outputString07 = test07.doExportIntoString();
			date = new Date();
			System.out.println(date.getTime() - oldDate.getTime());

			//do export into XML Document
			System.out.println("tree into XML Document: ");
			oldDate = new Date();
			DatabaseSQL2XML test08 = new DatabaseSQL2XML("treeXMLMapping.xml", "dbsql2xml.xsd", "", "");
			Document outDocument08 = test08.doExportIntoDocument();
			date = new Date();
			System.out.println(date.getTime() - oldDate.getTime());

			// TREE XML WITH CHARSET AND XINCLUSION
			//do export into standard output
			System.out.println("advanced tree into standard output: ");
			oldDate = new Date();
			DatabaseSQL2XML test09 = new DatabaseSQL2XML("treeXMLMappingWithXInclusionAndCharset.xml", "dbsql2xml.xsd", "", "");
			test09.doExportIntoStandardOutput();
			date = new Date();
			System.out.println(date.getTime() - oldDate.getTime());

			//do export into File
			System.out.println("advanced tree into File: ");
			oldDate = new Date();
			DatabaseSQL2XML test10 = new DatabaseSQL2XML("treeXMLMappingWithXInclusionAndCharset.xml", "dbsql2xml.xsd", "", "", "treeXMLMappingWithXInclusionAndCharsetOut.xml");
			test10.doExportIntoFile();
			date = new Date();
			System.out.println(date.getTime() - oldDate.getTime());

			//do export into String
			System.out.println("advanced tree into String: ");
			oldDate = new Date();
			DatabaseSQL2XML test11 = new DatabaseSQL2XML("treeXMLMappingWithXInclusionAndCharset.xml", "dbsql2xml.xsd", "", "");
			String outputString11 = test11.doExportIntoString();
			date = new Date();
			System.out.println(date.getTime() - oldDate.getTime());

			//do export into XML Document
			System.out.println("advanced tree into XML Document: ");
			oldDate = new Date();
			DatabaseSQL2XML test12 = new DatabaseSQL2XML("treeXMLMappingWithXInclusionAndCharset.xml", "dbsql2xml.xsd", "", "");
			Document outDocument12 = test12.doExportIntoDocument();
			date = new Date();
			System.out.println(date.getTime() - oldDate.getTime());
*/
		} catch (Exception e) {
			System.out.println(e.getMessage());
			System.out.println(e.getCause());
		} 
	}

}
