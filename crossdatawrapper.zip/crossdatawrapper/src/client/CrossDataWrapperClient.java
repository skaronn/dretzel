package client;

import java.io.IOException;

import main.CrossDataWrapper;

/**
 * 
 * @author adgnabro
 *
 */
public class CrossDataWrapperClient
{

	private static final String SAMPLE_TEST_DIR = "/sample/data/";

	public static void main(String[] args)
	{		

		try {
			CrossDataWrapper crossDataWrapper = new CrossDataWrapper();
			// XML base
//			crossDataWrapper.wrapData(SAMPLE_TEST_DIR + "example01.xml", "example01-1.xml");
//			crossDataWrapper.wrapData(SAMPLE_TEST_DIR + "example01.xml", "example01.json");
//			crossDataWrapper.wrapData(SAMPLE_TEST_DIR + "example01.xml", "example01.yml");
//			crossDataWrapper.wrapData(SAMPLE_TEST_DIR + "example01.xml", "example01.csv");

			// JSON base
//			crossDataWrapper.wrapData(SAMPLE_TEST_DIR + "example01.json", "example01.xml");
//			crossDataWrapper.wrapData(SAMPLE_TEST_DIR + "example01.json", "example01-1.json");
//			crossDataWrapper.wrapData(SAMPLE_TEST_DIR + "example01.json", "example01.yml");
//			crossDataWrapper.wrapData(SAMPLE_TEST_DIR + "example01.json", "example01.csv");

			// YAML base
//			crossDataWrapper.wrapData(SAMPLE_TEST_DIR + "example01.yml", "example01.xml");
//			crossDataWrapper.wrapData(SAMPLE_TEST_DIR + "example01.yml", "example01.json");
//			crossDataWrapper.wrapData(SAMPLE_TEST_DIR + "example01.yml", "example01-1.yml");
//			crossDataWrapper.wrapData(SAMPLE_TEST_DIR + "example01.yml", "example01.csv");

			// CSV base
			//crossDataWrapper.wrapData(SAMPLE_TEST_DIR + "example01.csv", "example01.xml");
			//crossDataWrapper.wrapData(SAMPLE_TEST_DIR + "example01.csv", "example01.json");
			//crossDataWrapper.wrapData(SAMPLE_TEST_DIR + "example01.csv", "example01.yml");
			//crossDataWrapper.wrapData(SAMPLE_TEST_DIR + "example01.csv", "example01-1.csv");
			
			// SQL base
			crossDataWrapper.wrapData(SAMPLE_TEST_DIR + "dbsql2xml/select.sql", "example01.xml");
			//crossDataWrapper.wrapData(SAMPLE_TEST_DIR + "dbsql2xml/productMappingToBeXIncludedIntoTreeXML.xml", "example01.sql");
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
	}
}
