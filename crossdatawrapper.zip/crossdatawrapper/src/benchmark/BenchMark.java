package benchmark;

import java.io.InputStream;
import java.io.InputStreamReader;

import main.Utils;

import com.esotericsoftware.yamlbeans.YamlException;
import com.esotericsoftware.yamlbeans.YamlReader;

public class BenchMark {
	
	public static void main(String[] args) {
		BenchMark benchMark = new BenchMark();
		runReadYamlBenckMark(benchMark);
	}

	private static void runReadYamlBenckMark(BenchMark benchMark)
	{		
		String path = "/sample/data/example01.yml";
		InputStream inputStreamFile = null;
		InputStreamReader yamlReader = null;			
		long start = 0;
		long elapsed = 0;
		Object object = null;
			
		//YamlBeans
		inputStreamFile = Utils.getInputStreamFromFile(benchMark, path);
		yamlReader = new InputStreamReader(inputStreamFile);	
		
		try {
			YamlReader yamlBeansReader = new YamlReader(yamlReader);
			start = System.currentTimeMillis();
			object = yamlBeansReader.read();
			elapsed = System.currentTimeMillis() - start;
			displayBenchmarkInfo("YamlBeans", object, elapsed);
		} catch (YamlException e) {
			e.printStackTrace();
		}
		
		//SnakeYaml
		inputStreamFile = Utils.getInputStreamFromFile(benchMark, path);
		yamlReader = new InputStreamReader(inputStreamFile);	
		org.yaml.snakeyaml.Yaml snakeYaml = new org.yaml.snakeyaml.Yaml();
		start = System.currentTimeMillis();
		object = snakeYaml.load(yamlReader);
		elapsed = System.currentTimeMillis() - start;
		displayBenchmarkInfo("SnakeYaml", object, elapsed);
		
		//Jvyaml
		inputStreamFile = Utils.getInputStreamFromFile(benchMark, path);
		yamlReader = new InputStreamReader(inputStreamFile);	
		start = System.currentTimeMillis();
		object = org.jvyaml.YAML.load(yamlReader);
		elapsed = System.currentTimeMillis() - start;
		displayBenchmarkInfo("Jvyaml", object, elapsed);
		
		//Jyaml
		inputStreamFile = Utils.getInputStreamFromFile(benchMark, path);
		yamlReader = new InputStreamReader(inputStreamFile);	
		start = System.currentTimeMillis();
		object = org.ho.yaml.Yaml.load(yamlReader);
		elapsed = System.currentTimeMillis() - start;	
		displayBenchmarkInfo("Jyaml", object, elapsed);
	}
	
	private static void displayBenchmarkInfo(String frameworkName, Object object, double elapsed)
	{
		System.err.println(frameworkName + " - elapsed time = " + elapsed + " milliseconds per execution");
		System.err.println(object);
		System.err.println(object.getClass());
		System.err.println("-------------------------------------------------------------------------------------");
	}

}
